/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      StubHDF_app.h
 *   @brief     This file contains the method declaration
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#ifndef CAMERAIMGSIGNAL_H
#define CAMERAIMGSIGNAL_H

#include <map>
#include <memory>
#include <iostream>
#include <unistd.h>
#include <ara/log/logging.h>
#include <ara/core/future.h>
#include <ara/core/promise.h>
#include "honda/cameraimgsignal/adas_acore_cameraimgsignal_sdd_service_skeleton.h"
#include "honda/cameraimgsignal/adas_acore_cameraimgsignal_sdd_service_common.h"
#include "CameraImgSignal.h"
#include "../inc/adaptive_app.h"

#include <ara/exec/deterministic_client.h>
#include <ara/exec/execution_client.h>


/// @brief This class represents
/// DataIdentifer Application
class CameraImgSignalApplication final : public AdaptiveApplication
{

public:
    CameraImgSignalApplication();

    CameraImgSignalApplication(const CameraImgSignalApplication&) = delete;

    CameraImgSignalApplication& operator=(const CameraImgSignalApplication&) = delete;

    CameraImgSignalApplication(CameraImgSignalApplication&&) = delete;

    CameraImgSignalApplication& operator=(CameraImgSignalApplication&&) = delete;

    ~CameraImgSignalApplication() = default;

    void MeasureEventPerformance(void);

    std::unique_ptr<honda::cameraimgsignal::CAMERAIMGSIGNAL_>serviceInstance_;
protected:
    bool OnInitialize() override;
    void Run() override;
    void OnTerminate() override;

private:

    ara::log::Logger& log_;
};

#endif // CAMERAIMGSIGNAL_H
