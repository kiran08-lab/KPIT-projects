/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      StubHDF.h
 *   @brief     This file contains the method declaration
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#ifndef DIDIMPL_H
#define DIDIMPL_H

#include <string>
#include <memory>
#include <ara/log/logging.h>
#include <ara/core/future.h>
#include <ara/core/promise.h>
#include "honda/cameraimgsignal/adas_acore_cameraimgsignal_sdd_service_skeleton.h"
#include "honda/cameraimgsignal/adas_acore_cameraimgsignal_sdd_service_common.h"
//#include "impl_type_dummymessage1.h"

using honda::cameraimgsignal::skeleton::ADAS_ACore_CameraImgSignal_SDD_ServiceSkeleton;

namespace honda
{
namespace cameraimgsignal
{

class CAMERAIMGSIGNAL_ : public honda::cameraimgsignal::skeleton::ADAS_ACore_CameraImgSignal_SDD_ServiceSkeleton
{

public :

    explicit CAMERAIMGSIGNAL_(ara::com::InstanceIdentifier instance_id);

//    ara::core::Future<void> MethodWithInputData(const ::ByteVectorType& data) override;

//    ara::core::Future<void> MethodWithoutInput() override;
 
    ara::log::Logger& m_logger{ara::log::CreateLogger("ST12", "SOMEIP_TCP_100KB_SER_TRUE", ara::log::LogLevel::kVerbose)};

    void SendEventCamImg(void)
    {
		std::cout << "[CAMERA] Sending event 2"  << std::endl;
        Cam2ProbePicture_STRUCTURE CamImg_buf;
		ADAS_CAM_IMG_IDC_EVT.Send(CamImg_buf); 
    }

};

}
}

#endif 
