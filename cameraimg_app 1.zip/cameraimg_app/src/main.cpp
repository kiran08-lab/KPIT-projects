/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      main.cpp
 *   @brief     This file contains the class implementation
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#include <exception>
#include <cstdint>
#include <unistd.h>
#include <iostream>
#include <cstdlib>
#include <type_traits>
#include <ara/log/logmanager.h>
#include <ara/log/logging.h>
#include "../inc/CameraImgSignal_app.h"
#include <ara/exec/execution_client.h>
#include "ara/core/initialization.h"

using namespace ara::log;

int main()
{
	ara::exec::ExecutionClient exec_client;
    exec_client.ReportExecutionState(ara::exec::ExecutionState::kRunning);
	if(!ara::core::Initialize()) {
		std::cerr << "Initialization failed. Exiting." << std::endl;
		std::cout << "[CAMERAIMG] Initialization failed. Exiting." << std::endl;
		return 1;
	}
	ara::log::Logger& logger{ara::log::CreateLogger("STB3", "SOMEIP_TCP_100KB_SER_TRUE", ara::log::LogLevel::kInfo)};

    logger.LogInfo() << "CameraImgSignal: Started .....";
	std::cout << "[CAMERAIMG] CameraImgSignal: Started ....." << std::endl;

    CameraImgSignalApplication app;

    return app.Execute();
}



