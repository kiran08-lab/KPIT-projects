This folder contains documents.
