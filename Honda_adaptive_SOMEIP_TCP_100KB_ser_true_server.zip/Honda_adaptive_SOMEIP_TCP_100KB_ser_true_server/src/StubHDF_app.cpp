/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      StubHDF_app.cpp
 *   @brief     This file contains the class implementation
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#include <string>
#include <iostream>
#include <cstdint>
#include <unistd.h>
#include "StubHDF_app.h"
#include <ara/exec/execution_client.h>
#include "ara/core/instance_specifier.h"
#include "honda/hdf/adas_acore_hdf_sdd_service_skeleton.h"
#include <sys/neutrino.h>
#include<chrono>
#define CC_TO_MICROS(clock_tick)   (((clock_tick)*UINT64_C(1000000)) / (SYSPAGE_ENTRY(qtime)->cycles_per_sec))
#include <ara/exec/exec_error_domain.h>
#define DELTA_TO_NS(delta) ( ((delta) * UINT64_C(1000000000)) / (SYSPAGE_ENTRY(qtime)->cycles_per_sec) )
#define DELTA_TO_MS(delta) ( ((delta) * UINT64_C(1000)) / (SYSPAGE_ENTRY(qtime)->cycles_per_sec) )

using ara::exec::ActivationReturnType;
using namespace ara::exec;

StubHDFApplication::StubHDFApplication()
    : log_(ara::log::CreateLogger("ST14", "SOMEIP_TCP_100KB_SER_TRUE"))
{

}

bool StubHDFApplication::OnInitialize()
{
    ReportRunningState();


    //ara::core::InstanceSpecifier portSpecifier{"ara/measure/swcs/StubECU/StubECU_p_port"};
	ara::core::InstanceSpecifier portSpecifier{"Application/AdaptiveApplicationSwComponentTypes/HDF/PPort_ADAS_Acore_HDF_HDF2CDCService"};
    /*auto instanceIDs = ara::com::runtime::ResolveInstanceIDs(portSpecifier);
    if (instanceIDs.empty()) {
        throw std::runtime_error{"No InstanceIdentifiers resolved from provided InstanceSpecifier"};
    }
    log_.LogWarn() << "Service Instance offered:" << instanceIDs[0].ToString();

    serviceInstance_ = std::make_unique<Honda::HDF::STUBHDF_>(instanceIDs[0]);*/
	auto instanceIDs_res = ara::com::runtime::ResolveInstanceIDs(portSpecifier);

	if (instanceIDs_res.Err().has_value()) 
	{
		log_.LogError()<<"Error : "<<instanceIDs_res.Error();
		throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}

	ara::com::InstanceIdentifierContainer instanceIDs = instanceIDs_res.Value(); //extracting the instanceIDs wrapped in ara::core::Result
	log_.LogInfo() << "Searching for Service Instance:" << instanceIDs[0].ToString();//Continue operations with instanceIDs
    serviceInstance_ = std::make_unique<Honda::HDF::STUBHDF_>(instanceIDs[0]);
	log_.LogWarn() << "StubECU APP instance is created  \n ";
    return true;
}
void StubHDFApplication::OnTerminate()
{
    log_.LogInfo() << "StubHDF Application terminating";
    serviceInstance_->StopOfferService();
}

void StubHDFApplication::MeasureEventPerformance(void)
{
	std::cout << " Started WaitUntilTermination"<< std::endl;
    auto sample = serviceInstance_->ADAS_CDC_EVT.Allocate();
	if (sample.Err().has_value())
	{
		std::cout<<"Error:"<< sample.Error() <<" "<< sample.Error().Message()<< std::endl;
	}
	else{
		auto l_sample = std::move(sample).Value();
		auto start_time = ClockCycles(); 
		serviceInstance_->ADAS_CDC_EVT.Send(*l_sample);
		std::cout << "After SEND_TIME: " << CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(start_time) << std::endl; 
		std::cout <<  "Size of l_sample SOMEIP_TCP_100KB_SER_TRUE: " << sizeof(*l_sample) << std::endl;
	}
	std::cout << " Completed WaitUntilTermination"<< std::endl;
}

// This method contains the implementation required for the DEterministic client and Runworkerpool
void StubHDFApplication::Run()
{
	//std::cout << "debug krun" << std::endl;
	//mkfifo("./run/sysstate-client-fifo", 0666);
	//system("rm -rf ./run/sysstate-client-fifo");
	// std::cout << " Started StubHDFApplication::Run() "<< std::endl;
	// serviceInstance_->OfferService();
	// std::cout << " Started While 1 "<< std::endl;

	// while(1)
	// {
	// 	MeasureEventPerformance();	
	// 	std::this_thread::sleep_for(std::chrono::milliseconds(100));
	// }

	ara::exec::ActivationReturnType response;
	ara::core::Result<ActivationReturnType> waitForRet_ = ara::core::Result<ActivationReturnType>::FromError(ExecErrc::kFailed);
	ara::exec::DeterministicClient deterministic;

	//while (true)
	while (!IsTerminateRequested())
	{
		waitForRet_= deterministic.WaitForActivation();
		if (waitForRet_.HasValue()) 
		{
			response = waitForRet_.Value();
		} 
		else{
			std::cout << " Wait for Activation returned Error condition "<< waitForRet_.Error()<< std::endl;
			response = ActivationReturnType::kRun;
		}
		switch (response)
		{			
			case ara::exec::ActivationReturnType::kInit:
			{
				std::cout << " Before serviceInstance_->OfferService()"<< std::endl;
				serviceInstance_->OfferService();
				std::cout << " After serviceInstance_->OfferService()"<< std::endl;
				break;
			}
			case ara::exec::ActivationReturnType::kRun:
			{
				std::cout << " Before MeasureEventPerformance"<< std::endl;
				MeasureEventPerformance();	
				std::cout << " After MeasureEventPerformance"<< std::endl;			
				break;
			}
			case ara::exec::ActivationReturnType::kTerminate:
			{
				std::cout << " Before WaitUntilTermination"<< std::endl;
				WaitUntilTermination();
				break;
			}
			default:
			{
				break;
			}
		}
	}
}
