/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      StubHDF.cpp
 *   @brief     This file contains the class implementation
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#include <string>
#include <iostream>
#include <cstdint>
#include "StubHDF.h"
#include <chrono>

namespace Honda
{
namespace HDF
{

STUBHDF_::STUBHDF_(ara::com::InstanceIdentifier instance_id)
 :ADAS_ACore_HDF_SDD_ServiceSkeleton(instance_id,ara::com::MethodCallProcessingMode::kEvent)
{
}

/*
ara::core::Future<void> STUBECU::MethodWithInputData(const ::ByteVectorType& )
{
    ara::core::Promise<void> promise;
    promise.set_value();
    return promise.get_future();
}

ara::core::Future<void> STUBECU::MethodWithoutInput()
{
    ara::core::Promise<void> promise;
    promise.set_value();
    return promise.get_future();
}
*/
}
}
