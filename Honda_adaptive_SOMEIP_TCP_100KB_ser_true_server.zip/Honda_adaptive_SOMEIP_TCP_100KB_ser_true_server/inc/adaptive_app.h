/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      adaptive_app.h
 *   @brief     This file contains the method declaration
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#ifndef ADAPTIVE_APP_H_
#define ADAPTIVE_APP_H_

#include <atomic>
#include <ara/log/logging.h>

class AdaptiveApplication
{
public:
    AdaptiveApplication() = default;

    AdaptiveApplication(const AdaptiveApplication&) = delete;
    AdaptiveApplication& operator=(const AdaptiveApplication&) = delete;

    AdaptiveApplication(AdaptiveApplication&&) = delete;
    AdaptiveApplication& operator=(AdaptiveApplication&&) = delete;

    virtual ~AdaptiveApplication() = default;

    int Execute();

protected:

    virtual bool OnInitialize();

    virtual void Run() = 0;

    virtual void OnTerminate();

	bool IsTerminateRequested();

    void WaitUntilTermination();

    void ReportRunningState();

private:
    bool Initialize();

    void ReportTerminatingState();

    void Terminate();

    void CloseSelfPipe();

    static constexpr int PipeReadingEnd = 0;

    static constexpr int PipeWritingEnd = 1;

    static int selfpipe[2];

    static std::atomic_bool exit_requested_;

    static void SigTermHandler(const int sig);

    ara::log::Logger& log_{ara::log::CreateLogger("ST10", "SOMEIP_TCP_100KB_SER_TRUE")};
};

#endif  // ADAPTIVE_APP_H_
