/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      StubHDF.h
 *   @brief     This file contains the method declaration
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#ifndef DIDIMPL_H
#define DIDIMPL_H

#include <string>
#include <memory>
#include <ara/log/logging.h>
#include <ara/core/future.h>
#include <ara/core/promise.h>
#include "honda/hdf/adas_acore_hdf_sdd_service_skeleton.h"
#include "honda/hdf/adas_acore_hdf_sdd_service_common.h"
//#include "impl_type_dummymessage1.h"

using Honda::HDF::skeleton::ADAS_ACore_HDF_SDD_ServiceSkeleton;

namespace Honda
{
namespace HDF
{

class STUBHDF_ : public Honda::HDF::skeleton::ADAS_ACore_HDF_SDD_ServiceSkeleton
{

public :

    explicit STUBHDF_(ara::com::InstanceIdentifier instance_id);

//    ara::core::Future<void> MethodWithInputData(const ::ByteVectorType& data) override;

//    ara::core::Future<void> MethodWithoutInput() override;
 
    ara::log::Logger& m_logger{ara::log::CreateLogger("ST12", "SOMEIP_TCP_100KB_SER_TRUE", ara::log::LogLevel::kVerbose)};
 
    void SendEvent(void)
    {
		std::cout << "Sending event 1"  << std::endl;
        HDF2stubCDC_message buffer;
		ADAS_CDC_EVT.Send(buffer); 
    }
};

}
}

#endif 
