/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      StubHDF_app.h
 *   @brief     This file contains the method declaration
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#ifndef DIDAPP_H
#define DIDAPP_H

#include <map>
#include <memory>
#include <iostream>
#include <unistd.h>
#include <ara/log/logging.h>
#include <ara/core/future.h>
#include <ara/core/promise.h>
#include "honda/hdf/adas_acore_hdf_sdd_service_skeleton.h"
#include "honda/hdf/adas_acore_hdf_sdd_service_common.h"
#include "StubHDF.h"
#include "../inc/adaptive_app.h"

#include <ara/exec/deterministic_client.h>
#include <ara/exec/execution_client.h>


/// @brief This class represents
/// DataIdentifer Application
class StubHDFApplication final : public AdaptiveApplication
{

public:
    StubHDFApplication();

    StubHDFApplication(const StubHDFApplication&) = delete;

    StubHDFApplication& operator=(const StubHDFApplication&) = delete;

    StubHDFApplication(StubHDFApplication&&) = delete;

    StubHDFApplication& operator=(StubHDFApplication&&) = delete;

    ~StubHDFApplication() = default;

    void MeasureEventPerformance(void);

    std::unique_ptr<Honda::HDF::STUBHDF_>serviceInstance_;
protected:
    bool OnInitialize() override;
    void Run() override;
    void OnTerminate() override;

private:

    ara::log::Logger& log_;
};

#endif // DIDAPP_H
