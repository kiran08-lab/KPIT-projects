/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      STUB_CDC_app.h
 *   @brief     This file contains the method declaration
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#ifndef DIDAPP_H
#define DIDAPP_H

#include <map>
#include <memory>
#include <iostream>
#include <unistd.h>
#include <atomic>
#include <ara/log/logging.h>
#include <ara/core/future.h>
#include <ara/core/promise.h>
#include "honda/camerahost/ad_adas_camerahost_cameraservice_proxy.h"
#include "honda/camerahost/ad_adas_camerahost_cameraservice_common.h"
#include "honda/cameraimgsignal/adas_acore_cameraimgsignal_sdd_service_common.h"
#include "honda/cameraimgsignal/adas_acore_cameraimgsignal_sdd_service_proxy.h"
#include "honda/camerahost/ad_adas_camerahost_vehicleservice_proxy.h"
#include "honda/camerahost/ad_adas_camerahost_vehicleservice_common.h"
#include "honda/camerahost/ad_adas_camerahost_interruptservice_proxy.h"
#include "honda/camerahost/ad_adas_camerahost_interruptservice_common.h"
#include "honda/radarhost/ad_adas_camerahost_radarservice_proxy.h"
#include "honda/radarhost/ad_adas_camerahost_radarservice_common.h"
#include "../inc/adaptive_app.h"

#include <ara/exec/deterministic_client.h>
#include <ara/exec/execution_client.h>

//#include "impl_type_hdf2stubcdc_message.h"

volatile static std::sig_atomic_t sig_value;

using honda::camerahost::proxy::AD_ADAS_CameraHost_CameraServiceProxy;
using honda::cameraimgsignal::proxy::ADAS_ACore_CameraImgSignal_SDD_ServiceProxy;
using honda::camerahost::proxy::AD_ADAS_CameraHost_VehicleServiceProxy;
using honda::camerahost::proxy::AD_ADAS_CameraHost_InterruptServiceProxy;
using honda::radarhost::proxy::AD_ADAS_CameraHost_RadarServiceProxy;
using ara::com::InstanceIdentifier;
	
/// @brief This class represents
/// DataIdentifer Application
class STUBCDCApplication final : public AdaptiveApplication
{

public:
    
	STUBCDCApplication();

	STUBCDCApplication(const STUBCDCApplication&) = delete;

	STUBCDCApplication& operator=(const STUBCDCApplication&) = delete;

	STUBCDCApplication(STUBCDCApplication&&) = delete;

	STUBCDCApplication& operator=(STUBCDCApplication&&) = delete;

    ~STUBCDCApplication() = default;

	uint16_t serviceInstanceCamera_;
	uint16_t serviceInstanceCameraImage_;
	uint16_t serviceInstanceVehicle_;
	uint16_t radarServiceInstance_;
	uint16_t serviceInstanceInterrupt_;

    void FindService();	
	
	void cameraServiceAvailabilityCallback(ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_CameraServiceProxy::HandleType> handles, ara::com::FindServiceHandle );
	void vehicleServiceAvailabilityCallback(ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_VehicleServiceProxy::HandleType> handles, ara::com::FindServiceHandle );
	void serviceAvailabilityCallbackRadar(ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_RadarServiceProxy::HandleType> handles, ara::com::FindServiceHandle );
	void interruptServiceAvailabilityCallback(ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_InterruptServiceProxy::HandleType> handles, ara::com::FindServiceHandle );
	void cameraImageServiceAvailabilityCallback(ara::com::ServiceHandleContainer<ADAS_ACore_CameraImgSignal_SDD_ServiceProxy::HandleType> handles, ara::com::FindServiceHandle );


	void SetUpPMProxyCamera(honda::camerahost::proxy::AD_ADAS_CameraHost_CameraServiceProxy::HandleType handle);
	void SetUpPMProxyCameraImage(honda::cameraimgsignal::proxy::ADAS_ACore_CameraImgSignal_SDD_ServiceProxy::HandleType handle);
	void SetUpPMProxyVehicle(honda::camerahost::proxy::AD_ADAS_CameraHost_VehicleServiceProxy::HandleType handle);
	void SetUpRadarProxy(honda::radarhost::proxy::AD_ADAS_CameraHost_RadarServiceProxy::HandleType handle);
	void SetUpPMProxyInterrupt(honda::camerahost::proxy::AD_ADAS_CameraHost_InterruptServiceProxy::HandleType handle);
	
	std::shared_ptr<honda::camerahost::proxy::AD_ADAS_CameraHost_CameraServiceProxy> pm_proxy_camera_ = nullptr;
	std::shared_ptr<honda::cameraimgsignal::proxy::ADAS_ACore_CameraImgSignal_SDD_ServiceProxy> pm_proxy_camera_image_ = nullptr;
	std::shared_ptr<honda::camerahost::proxy::AD_ADAS_CameraHost_VehicleServiceProxy> pm_proxy_vehicle_ = nullptr;
	std::shared_ptr<honda::radarhost::proxy::AD_ADAS_CameraHost_RadarServiceProxy> radar_proxy_ = nullptr;
	std::shared_ptr<honda::camerahost::proxy::AD_ADAS_CameraHost_InterruptServiceProxy> pm_proxy_interrupt_ = nullptr;
	
	void CameraReceiveData(void);
	void CameraImageReceiveData(void);
	void VehicleReceiveData(void);
	void RadarReceiveData(void);
	void InterruptReceiveData(void);

	

	// model step function
    void step();
	void act();
	
	static bool IsDataReceived();
	static uint64_t gns_time();
	
protected:
    bool OnInitialize() override;
    void Run() override;
    void OnTerminate() override;
	
private:
	static uint64_t gns_time_ms;
	static bool is_data_size_correct;
	static bool is_callback_received;
    //ara::log::Logger& log_;
	bool is_data_received_=false;
	//HDF2stubCDC_message Rec_Data{};
	
	

};

#endif // DIDAPP_H
