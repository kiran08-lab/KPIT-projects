/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      STUB_CDC_app.cpp
 *   @brief     This file contains the class implementation
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#include <iomanip>
#include <cstdint>
#include <string>
#include <iostream>
#include <unistd.h>
#include <csignal>
#include <atomic>
#include <ara/log/logging.h>
#include <ara/exec/execution_client.h>
#include "STUB_CDC_app.h"
#include "ara/core/instance_specifier.h"
#include <chrono>
#include <sys/neutrino.h>
#include <ara/core/steady_clock.h>
#include <ara/core/result.h>
#include <ara/exec/exec_error_domain.h>
#define CC_TO_MICROS(clock_tick) (((clock_tick)*UINT64_C(1000000)) / (SYSPAGE_ENTRY(qtime)->cycles_per_sec))
#define DELTA_TO_NS(delta) ( ((delta) * UINT64_C(1000000000)) / (SYSPAGE_ENTRY(qtime)->cycles_per_sec) )
using ara::exec::ActivationReturnType;
using namespace ara::exec;

bool STUBCDCApplication::is_data_size_correct = false;
bool STUBCDCApplication::is_callback_received = false;

uint64_t STUBCDCApplication::gns_time_ms = 0;

//#define SIZE_1MB 1048576 // define 1MB in bytes
#define SIZE_100KB 102400 // define 100KB in bytes

//static  HDF2stubCDC_message Rec_Infodata{};
//static HDF2stubCDC_message vecRf5FsTimestampSec{};

STUBCDCApplication::STUBCDCApplication()
    // : log_(ara::log::CreateLogger("STB6", "SOMEIP_TCP_100KB_SER_TRUE", ara::log::LogLevel::kVerbose))
{
}

bool STUBCDCApplication::OnInitialize()
{
    std::cout <<"[IDC] OnInitialize \n";
    // camera Instance
    ara::core::InstanceSpecifier portSpecifierCamera{"Application/AdaptiveApplicationSwComponentTypes/HADASRADIQ/RPort_HADASRADIQ_AD_ADAS_CameraHost_CameraService_SOMEIP"};
	auto instanceIDs_resCamera = ara::com::runtime::ResolveInstanceIDs(portSpecifierCamera);
    std::cout <<"[IDC] Got Camera instanceIDs_res \n";
	if (instanceIDs_resCamera.Err().has_value()) 
	{
		std::cout << "[IDC] Error Camera : "<< instanceIDs_resCamera.Error() << "\n";
		//throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}
    std::cout <<"[IDC] camera instanceIDs_res error check \n";
	ara::com::InstanceIdentifierContainer instanceIDsCamera = instanceIDs_resCamera.Value(); //extracting the instanceIDs wrapped in ara::core::Result
	std::cout << "[IDC] Searching for camera Service Instance:" << instanceIDsCamera[0].ToString();//Continue operations with instanceIDs
    serviceInstanceCamera_ = instanceIDsCamera[0];
    std::cout << "[IDC] camera instance is created ";
	
    //camera Image Instance
    ara::core::InstanceSpecifier portSpecifierCameraImage{"Application/AdaptiveApplicationSwComponentTypes/HADASRADIQ/RPort_ADAS_Acore_CameraImgSignal_CameraImg2IDCService"};
    auto instanceIDs_resCameraImage = ara::com::runtime::ResolveInstanceIDs(portSpecifierCameraImage);
    std::cout <<"[IDC] Got Camera Image instanceIDs_res \n";
    if (instanceIDs_resCameraImage.Err().has_value())
    {
        std::cout << "[IDC] Error Camera Image : "<< instanceIDs_resCameraImage.Error() << "\n";
        //throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
    }
    std::cout <<"[IDC] camera Image instanceIDs_res error check \n";
    ara::com::InstanceIdentifierContainer instanceIDsCameraImage = instanceIDs_resCameraImage.Value(); //extracting the instanceIDs wrapped in ara::core::Result
    std::cout << "[IDC] Searching for camera Image Service Instance:" << instanceIDsCameraImage[0].ToString();//Continue operations with instanceIDs
    serviceInstanceCameraImage_ = instanceIDsCameraImage[0];
    std::cout << "[IDC] camera Image instance is created ";

	/*Radar*/
    ara::core::InstanceSpecifier radarPortSpecifier{"Application/AdaptiveApplicationSwComponentTypes/HADASRADIQ/RPort_HADASRADIQ_AD_ADAS_CameraHost_RadarService_SOMEIP"};
	auto radarInstanceIDs_res = ara::com::runtime::ResolveInstanceIDs(radarPortSpecifier);
    std::cout <<"[IDC] Radar instanceIDs_res \n";
	if (radarInstanceIDs_res.Err().has_value()) 
	{
		std::cout << "[IDC] Error Radar : "<< radarInstanceIDs_res.Error() << "\n";
		//throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}
    std::cout <<"[IDC] Radar instanceIDs_res error check \n";
	ara::com::InstanceIdentifierContainer radarInstanceIDs = radarInstanceIDs_res.Value(); //extracting the instanceIDs wrapped in ara::core::Result
	std::cout << "[IDC] Searching for Radar Service Instance:" << radarInstanceIDs[0].ToString();//Continue operations with instanceIDs
    radarServiceInstance_ = radarInstanceIDs[0];
    std::cout << "[IDC] Radar OnInitialize instance is created ";
	
    // Vehicle instance 
    ara::core::InstanceSpecifier portSpecifierVehicle{"Application/AdaptiveApplicationSwComponentTypes/HADASRADIQ/RPort_HADASRADIQ_AD_ADAS_CameraHost_VehicleService_SOMEIP"};
	auto instanceIDs_resVehicle = ara::com::runtime::ResolveInstanceIDs(portSpecifierVehicle);
    std::cout <<"[IDC] Got Vehicle instanceIDs_res \n";
	if (instanceIDs_resVehicle.Err().has_value()) 
	{
		std::cout << "[IDC] Error Vehicle : "<< instanceIDs_resVehicle.Error() << "\n";
		//throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}
    std::cout <<"[IDC] Vehicle instanceIDs_res error check \n";
	ara::com::InstanceIdentifierContainer instanceIDsVehicle = instanceIDs_resVehicle.Value(); //extracting the instanceIDs wrapped in ara::core::Result
	std::cout << "[IDC] Searching for Vehicle Service Instance:" << instanceIDsVehicle[0].ToString();//Continue operations with instanceIDs
    serviceInstanceVehicle_ = instanceIDsVehicle[0];
    std::cout << "[IDC] Vehicle instance is created ";

    // Interrupt instance 
    ara::core::InstanceSpecifier portSpecifierInterrupt{"Application/AdaptiveApplicationSwComponentTypes/HADASRADIQ/RPort_HADASRADIQ_AD_ADAS_CameraHost_InterruptService_SOMEIP"};
	auto instanceIDs_resInterrupt = ara::com::runtime::ResolveInstanceIDs(portSpecifierInterrupt);
    std::cout <<"[IDC] Got Interrupt instanceIDs_res \n";
	if (instanceIDs_resInterrupt.Err().has_value()) 
	{
		std::cout << "[IDC] Error Interrupt : "<< instanceIDs_resInterrupt.Error() << "\n";
		//throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}
    std::cout <<"[IDC] Interrupt instanceIDs_res error check \n";
	ara::com::InstanceIdentifierContainer instanceIDsInterrupt = instanceIDs_resInterrupt.Value(); //extracting the instanceIDs wrapped in ara::core::Result
	std::cout << "[IDC] Searching for Interrupt Service Instance:" << instanceIDsInterrupt[0].ToString();//Continue operations with instanceIDs
    serviceInstanceInterrupt_ = instanceIDsInterrupt[0];
    std::cout << "[IDC] Interrupt instance is created ";

    return true;
}

void STUBCDCApplication::OnTerminate()
{
    std::cout << "[IDC] Application terminating";
}

void STUBCDCApplication::FindService()
{
    std::cout << "[IDC] FindService Camera started ...\n";
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    AD_ADAS_CameraHost_CameraServiceProxy::StartFindService(
    [this](ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_CameraServiceProxy::HandleType> camera_handles,
    ara::com::FindServiceHandle camera_handler)
    {
        cameraServiceAvailabilityCallback(std::move(camera_handles), camera_handler);
    });
    std::cout << "[IDC] Findservice Camera is completed" << std::endl;

    ADAS_ACore_CameraImgSignal_SDD_ServiceProxy::StartFindService(
    [this](ara::com::ServiceHandleContainer<ADAS_ACore_CameraImgSignal_SDD_ServiceProxy::HandleType> camera_image_handles,
    ara::com::FindServiceHandle camera_image_handler)
    {
        cameraImageServiceAvailabilityCallback(std::move(camera_image_handles), camera_image_handler);
    });
    std::cout << "[IDC] Findservice Camera Image is completed" << std::endl;

	AD_ADAS_CameraHost_RadarServiceProxy::StartFindService(
    [this](ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_RadarServiceProxy::HandleType> handles,
    ara::com::FindServiceHandle handler)
    {
        serviceAvailabilityCallbackRadar(std::move(handles), handler);
    });
    std::cout<<"[IDC] Findservice is completed for Radar "<<std::endl;
    
    std::cout << "[IDC] FindService Vehicle started ...\n";
    AD_ADAS_CameraHost_VehicleServiceProxy::StartFindService(
    [this](ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_VehicleServiceProxy::HandleType> vehicle_handles,
    ara::com::FindServiceHandle vehicle_handler)
    {
        vehicleServiceAvailabilityCallback(std::move(vehicle_handles), vehicle_handler);
    });
    std::cout << "[IDC] Findservice Vehicle is completed" << std::endl;

    std::cout << "[IDC] FindService Interrupt started ...\n";
    AD_ADAS_CameraHost_InterruptServiceProxy::StartFindService(
    [this](ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_InterruptServiceProxy::HandleType> interrupt_handles,
    ara::com::FindServiceHandle interrupt_handler)
    {
        interruptServiceAvailabilityCallback(std::move(interrupt_handles), interrupt_handler);
    });
    std::cout << "[IDC] Findservice Interrupt is completed" << std::endl;

}

void STUBCDCApplication::cameraServiceAvailabilityCallback(ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_CameraServiceProxy::HandleType> handles,
        ara::com::FindServiceHandle )
{
    std::cout << "[IDC] Callback received camera, Found handles " << handles.size() << std::endl;

    if (0u < handles.size()) {
        std::cout<<"[IDC] inside if condition for camera handle"<<std::endl;
        for (auto it : handles) {
        if (nullptr == pm_proxy_camera_ && serviceInstanceCamera_ ==  static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "GetInstanceId for camera = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetUpPMProxyCamera(handles[0]);   
            }
        }
    } else if ((0u == handles.size()) && this->pm_proxy_camera_) {
        // previously registered handle is now no vehicleProxy present, reset proxy_
        this->pm_proxy_camera_.reset();
    } else {
            std::cout<<"[IDC] handles.size() is 0 and proxy is not assigned for camera"<<std::endl;
        // means handles.size() is 0 and proxy is not assigned, though this should not happen it's no problem
    }
    std::cout<<"[IDC] ServiceAvailabilitycallback is completed for camera"<<std::endl;
	is_callback_received = true;
    return;
}

void STUBCDCApplication::cameraImageServiceAvailabilityCallback(ara::com::ServiceHandleContainer<ADAS_ACore_CameraImgSignal_SDD_ServiceProxy::HandleType> handles,
        ara::com::FindServiceHandle )
{
    std::cout << "[IDC] Callback received camera image, Found handles " << handles.size() << std::endl;

    if (0u < handles.size()) {
        std::cout<<"[IDC] inside if condition for camera image handle"<<std::endl;
        for (auto it : handles) {
        if (nullptr == pm_proxy_camera_image_ && serviceInstanceCameraImage_ ==  static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "GetInstanceId for camera image = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetUpPMProxyCameraImage(handles[0]);   
            }
        }
    } else if ((0u == handles.size()) && this->pm_proxy_camera_image_) {
        // previously registered handle is now no vehicleProxy present, reset proxy_
        this->pm_proxy_camera_image_.reset();
    } else {
            std::cout<<"[IDC] handles.size() is 0 and proxy is not assigned for camera image"<<std::endl;
        // means handles.size() is 0 and proxy is not assigned, though this should not happen it's no problem
    }
    std::cout<<"[IDC] ServiceAvailabilitycallback is completed for camera image"<<std::endl;
    is_callback_received = true;
    return;
}

void STUBCDCApplication::vehicleServiceAvailabilityCallback(ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_VehicleServiceProxy::HandleType> handles,
        ara::com::FindServiceHandle )
{
    std::cout << "[IDC] Callback received vehicle, Found handles " << handles.size() << std::endl;

    if (0u < handles.size()) {
        std::cout<<"[IDC] inside if condition for vehicle handle"<<std::endl;
        for (auto it : handles) {
        if (nullptr == pm_proxy_vehicle_ && serviceInstanceVehicle_ ==  static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "GetInstanceId for vehicle = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetUpPMProxyVehicle(handles[0]);   
            }
        }
    } else if ((0u == handles.size()) && this->pm_proxy_vehicle_) {
        // previously registered handle is now no vehicleProxy present, reset proxy_
        this->pm_proxy_vehicle_.reset();
    } else {
            std::cout<<"[IDC] handles.size() is 0 and proxy is not assigned for vehicle"<<std::endl;
        // means handles.size() is 0 and proxy is not assigned, though this should not happen it's no problem
    }
    std::cout<<"[IDC] ServiceAvailabilitycallback is completed for vehicle"<<std::endl;
	is_callback_received = true;
    return;
}

void STUBCDCApplication::interruptServiceAvailabilityCallback(ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_InterruptServiceProxy::HandleType> handles, ara::com::FindServiceHandle)
{
    std::cout << "[IDC] Callback received Interrupt, Found handles " << handles.size() << std::endl;

    if (0u < handles.size()) {
        std::cout<<"[IDC] inside if condition for Interrupt handle"<<std::endl;
        for (auto it : handles) {
        if (nullptr == pm_proxy_interrupt_ && serviceInstanceInterrupt_ ==  static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "GetInstanceId for Interrupt = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetUpPMProxyInterrupt(handles[0]);   
            }
        }
    } else if ((0u == handles.size()) && this->pm_proxy_interrupt_) {
        // previously registered handle is now no vehicleProxy present, reset proxy_
        this->pm_proxy_interrupt_.reset();
    } else {
            std::cout<<"[IDC] handles.size() is 0 and proxy is not assigned for Interrupt"<<std::endl;
        // means handles.size() is 0 and proxy is not assigned, though this should not happen it's no problem
    }
    std::cout<<"[IDC] ServiceAvailabilitycallback is completed for Interrupt"<<std::endl;
	is_callback_received = true;
    return;
}

void STUBCDCApplication::SetUpPMProxyCamera(AD_ADAS_CameraHost_CameraServiceProxy::HandleType handle)
{
    this->pm_proxy_camera_ = std::make_shared<AD_ADAS_CameraHost_CameraServiceProxy>(handle);
    this->pm_proxy_camera_->AD_ADAS_CameraHost_CameraService_LANES_INFO_EVT.Subscribe(1);
    this->pm_proxy_camera_->AD_ADAS_CameraHost_CameraService_LANES_INFO_EVT.SetReceiveHandler([this]() { CameraReceiveData(); });

    std::cout << "[IDC] STUBCDCApplication::SetUpPMProxy for Camera event"  << std::endl;

    if (this->pm_proxy_camera_->AD_ADAS_CameraHost_CameraService_LANES_INFO_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    {
        std::cout << "[IDC] Camera Subscribed successfully!!" << std::endl;
    }
    else
    {
        std::cout << "[IDC] Camera Subscription failed!!" << std::endl;
    }

    // this->pm_proxy_->AD_ADAS_CameraHost_CameraService_RM_SL_INFO_EVT.Subscribe(1);
    // this->pm_proxy_->AD_ADAS_CameraHost_CameraService_RM_SL_INFO_EVT.SetReceiveHandler([this]() { VehicleReceiveData(); });

    // std::cout << "[IDC] STUBCDCApplication::SetUpPMProxy for Vehicle event"  << std::endl;

    // if (this->pm_proxy_->AD_ADAS_CameraHost_CameraService_RM_SL_INFO_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    // {
    //     std::cout << "[IDC] Vehicle Subscribed successfully!!" << std::endl;
    // }
    // else
    // {
    //     std::cout << "[IDC] Vehicle Subscription failed!!" << std::endl;
    // }
}

void STUBCDCApplication::SetUpPMProxyVehicle(AD_ADAS_CameraHost_VehicleServiceProxy::HandleType handle)
{
    this->pm_proxy_vehicle_ = std::make_shared<AD_ADAS_CameraHost_VehicleServiceProxy>(handle);
    this->pm_proxy_vehicle_->AD_ADAS_CameraHost_VehicleService_EVT.Subscribe(1);
    this->pm_proxy_vehicle_->AD_ADAS_CameraHost_VehicleService_EVT.SetReceiveHandler([this]() { VehicleReceiveData(); });

    std::cout << "[IDC] STUBCDCApplication::SetUpPMProxy for vehicle event"  << std::endl;

    if (this->pm_proxy_vehicle_->AD_ADAS_CameraHost_VehicleService_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    {
        std::cout << "[IDC] vehicle Subscribed successfully!!" << std::endl;
    }
    else
    {
        std::cout << "[IDC] vehicle Subscription failed!!" << std::endl;
    }
}

void STUBCDCApplication::SetUpPMProxyCameraImage(ADAS_ACore_CameraImgSignal_SDD_ServiceProxy::HandleType handle)
{
    this->pm_proxy_camera_image_ = std::make_shared<ADAS_ACore_CameraImgSignal_SDD_ServiceProxy>(handle);
    this->pm_proxy_camera_image_->ADAS_CAM_IMG_IDC_EVT.Subscribe(1);
    this->pm_proxy_camera_image_->ADAS_CAM_IMG_IDC_EVT.SetReceiveHandler([this]() { CameraImageReceiveData(); });

    std::cout << "[IDC] STUBCDCApplication::SetUpPMProxy for Camera Image event"  << std::endl;

    if (this->pm_proxy_camera_image_->ADAS_CAM_IMG_IDC_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    {
        std::cout << "[IDC] Camera Image Subscribed successfully!!" << std::endl;
    }
    else
    {
        std::cout << "[IDC] Camera Image Subscription failed!!" << std::endl;
    }
}

void STUBCDCApplication::SetUpPMProxyInterrupt(honda::camerahost::proxy::AD_ADAS_CameraHost_InterruptServiceProxy::HandleType handle)
{
    this->pm_proxy_interrupt_ = std::make_shared<AD_ADAS_CameraHost_InterruptServiceProxy>(handle);
    this->pm_proxy_interrupt_->AD_ADAS_CameraHost_InterruptService_EVT.Subscribe(1);
    this->pm_proxy_interrupt_->AD_ADAS_CameraHost_InterruptService_EVT.SetReceiveHandler([this]() { InterruptReceiveData(); });

    std::cout << "[IDC] STUBCDCApplication::SetUpPMProxy for Interrupt event"  << std::endl;

    if (this->pm_proxy_interrupt_->AD_ADAS_CameraHost_InterruptService_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    {
        std::cout << "[IDC] Interrupt Subscribed successfully!!" << std::endl;
    }
    else
    {
        std::cout << "[IDC] Interrupt Subscription failed!!" << std::endl;
    }
}

void printStructAsHex(const void* obj, size_t size) {    
    // Cast the object pointer to a byte pointerconst 
    auto* bytes = reinterpret_cast<const uint8_t*>(obj);  
    // Save current cout state flags
    std::ios_base::fmtflags f(std::cout.flags());       
    std::cout << "0x" << std::hex << std::setfill('0');     
    for (size_t i = 0; i < size; ++i) {        
        // cast to int because cout prints uint8_t as a char character
        std::cout << std::setw(2) << static_cast<int>(bytes[i]);  
    }     
    std::cout << std::endl;   
    // Restore original cout flags
    std::cout.flags(f); 
}

void STUBCDCApplication::CameraReceiveData()
{
   std::cout << "[IDC] inside the camera data Receiver" << std::endl;
	uint64_t GNS_start = ClockCycles();
	
	std::size_t received_data = 0;
	
    auto callback = [this ,GNS_start, &received_data](auto sample)
    {
		//uint64_t GNS_time = CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(GNS_start);
		
		//std::cout << "GNS time in micro seconds "<< GNS_time << std::endl;
		
		std::cout << "[IDC] Received Camera data in subscriber size : " << sizeof(*sample)<< std::endl;
        std::cout << "[IDC] Camera Data = ";
        printStructAsHex(&(*sample), sizeof(*sample));
		//received_data = sizeof(*sample);
		//gns_time_ms = GNS_time;
	};
	
    this->pm_proxy_camera_->AD_ADAS_CameraHost_CameraService_LANES_INFO_EVT.GetNewSamples(callback, 1);	
	
	if(received_data == SIZE_100KB) {
		is_data_size_correct = true;
	}
	
//     this->pm_proxy_->AD_ADAS_CameraHost_CameraService_LANES_INFO_EVT.Cleanup();
}

void STUBCDCApplication::CameraImageReceiveData()
{
   std::cout << "[IDC] inside the camera image data Receiver" << std::endl;
    uint64_t GNS_start = ClockCycles();
    
    std::size_t received_data = 0;
    
    auto callback = [this ,GNS_start, &received_data](auto sample)
    {
        //uint64_t GNS_time = CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(GNS_start);
        
        //std::cout << "GNS time in micro seconds "<< GNS_time << std::endl;
        
        std::cout << "[IDC] Received Camera Image data in subscriber size : " << sizeof(*sample)<< std::endl;
        std::cout << "[IDC] Camera Image Data = ";
        printStructAsHex(&(*sample), sizeof(*sample));
        //received_data = sizeof(*sample);
        //gns_time_ms = GNS_time;
    };
    
    this->pm_proxy_camera_image_->ADAS_CAM_IMG_IDC_EVT.GetNewSamples(callback, 1);	
    
    if(received_data == SIZE_100KB) {
        is_data_size_correct = true;
    }
}

void STUBCDCApplication::VehicleReceiveData()
{
   std::cout << "[IDC] inside the Vehicle data Receiver" << std::endl;
	uint64_t GNS_start = ClockCycles();
	
	std::size_t received_data = 0;
	
    auto callback = [this ,GNS_start, &received_data](auto sample)
    {
		//uint64_t GNS_time = CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(GNS_start);
		
		//std::cout << "GNS time in micro seconds "<< GNS_time << std::endl;
		
		std::cout << "[IDC] Received Vehicle data in subscriber size : " << sizeof(*sample)<< std::endl;
		std::cout << "[IDC] Vehicle Data = ";
        printStructAsHex(&(*sample), sizeof(*sample));
		//received_data = sizeof(*sample);
		//gns_time_ms = GNS_time;
	};
	
    this->pm_proxy_vehicle_->AD_ADAS_CameraHost_VehicleService_EVT.GetNewSamples(callback, 1);	
	
	if(received_data == SIZE_100KB) {
		is_data_size_correct = true;
	}
	
//     this->pm_proxy_->AD_ADAS_CameraHost_CameraService_LANES_INFO_EVT.Cleanup();
}

void STUBCDCApplication::InterruptReceiveData(void)
{
    std::cout << "[IDC] inside the Interrupt Receiver" << std::endl;
	uint64_t GNS_start = ClockCycles();
	
	std::size_t received_data = 0;
	
    auto callback = [this ,GNS_start, &received_data](auto sample)
    {
		//uint64_t GNS_time = CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(GNS_start);
		
		//std::cout << "GNS time in micro seconds "<< GNS_time << std::endl;
		
		std::cout << "[IDC] Received Interrupt in subscriber size : " << sizeof(*sample)<< std::endl;
		std::cout << "[IDC] Interrupt = ";
        printStructAsHex(&(*sample), sizeof(*sample));
		//received_data = sizeof(*sample);
		//gns_time_ms = GNS_time;
	};
	
    this->pm_proxy_interrupt_->AD_ADAS_CameraHost_InterruptService_EVT.GetNewSamples(callback, 1);	
	
	if(received_data == SIZE_100KB) {
		is_data_size_correct = true;
	}
}

void STUBCDCApplication::serviceAvailabilityCallbackRadar(ara::com::ServiceHandleContainer<AD_ADAS_CameraHost_RadarServiceProxy::HandleType> handles,
        ara::com::FindServiceHandle )
{
    std::cout << "[IDC] Callback received STUBCDC, Found handles " << handles.size() << std::endl;

    if (0u < handles.size()) {
        std::cout<<"[IDC] inside if condition for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
        for (auto it : handles) {
        if (nullptr == radar_proxy_ && radarServiceInstance_ ==  static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "GetInstanceId for SOMEIP_TCP_100KB_SER_TRUE = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetUpRadarProxy(handles[0]);   
            }
        }
    } else if ((0u == handles.size()) && this->radar_proxy_) {
        // previously registered handle is now no vehicleProxy present, reset proxy_
        this->radar_proxy_.reset();
    } else {
            std::cout<<"[IDC] handles.size() is 0 and proxy is not assigned"<<std::endl;
        // means handles.size() is 0 and proxy is not assigned, though this should not happen it's no problem
    }
    std::cout<<"[IDC] ServiceAvailabilitycallbackRadar is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
	is_callback_received = true;
    return;
}

void STUBCDCApplication::SetUpRadarProxy(AD_ADAS_CameraHost_RadarServiceProxy::HandleType handle)
{
    this->radar_proxy_ = std::make_shared<AD_ADAS_CameraHost_RadarServiceProxy>(handle);
    this->radar_proxy_->AD_ADAS_CameraHost_RadarService_LANES_INFO_EVT.Subscribe(1);
    this->radar_proxy_->AD_ADAS_CameraHost_RadarService_LANES_INFO_EVT.SetReceiveHandler([this]() { RadarReceiveData(); });

    std::cout << "[IDC] STUBCDCApplication::SetUpRadarProxy for Camera event"  << std::endl;

    if (this->radar_proxy_->AD_ADAS_CameraHost_RadarService_LANES_INFO_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    {
        std::cout << "[IDC] Radar Subscribed successfully!!" << std::endl;
    }
    else
    {
        std::cout << "[IDC] Radar Subscription failed!!" << std::endl;
    }

}

void STUBCDCApplication::RadarReceiveData()
{
   std::cout << "[IDC] inside the Radar data Receiver" << std::endl;
	uint64_t GNS_start = ClockCycles();
	
	std::size_t received_data = 0;
	
    auto callback = [this ,GNS_start, &received_data](auto sample)
    {
		//uint64_t GNS_time = CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(GNS_start);
		
		//std::cout << "GNS time in micro seconds "<< GNS_time << std::endl;
		
		std::cout << "[IDC] Received Radar data in subscriber size : " << sizeof(*sample)<< std::endl;
		std::cout << "[IDC] Radar Data = ";
        printStructAsHex(&(*sample), sizeof(*sample));
		//received_data = sizeof(*sample);
		//gns_time_ms = GNS_time;
	};
	
    this->radar_proxy_->AD_ADAS_CameraHost_RadarService_LANES_INFO_EVT.GetNewSamples(callback, 1);	
	
	if(received_data == SIZE_100KB) {
		is_data_size_correct = true;
	}
	
//     this->pm_proxy_->AD_ADAS_CameraHost_CameraService_LANES_INFO_EVT.Cleanup();
}

// Model step function
void STUBCDCApplication::step()
{
    if (is_data_received_)
    {
        std::cout << "[IDC]  Data recieved!!!!" << std::endl;
        //Rec_Infodata = Rec_Data;    
    }
}

// This method contains the implementation required for the DEterministic client and Runworkerpool
void STUBCDCApplication::Run()
{
    std::cout << "[IDC] inside Run \n";
    //mkfifo("./run/sysstate-client-fifo", 0666);
	FindService();
	WaitUntilTermination();
	//system("rm -rf ./run/sysstate-client-fifo");
	/*
    ara::exec::ActivationReturnType response;
	ara::core::Result<ActivationReturnType> waitForRet_ = ara::core::Result<ActivationReturnType>::FromError(ExecErrc::kFailed);
    ara::exec::DeterministicClient deterministic;
    
	//while (app_terminate_flag == false)
	
    while (sig_value == 0)
    {
	   waitForRet_= deterministic.WaitForActivation();
	   if (waitForRet_.HasValue()) 
		{
          response = waitForRet_.Value();
        } else
		{
          std::cout << " Wait for Activation returned Error condition "<< waitForRet_.Error()<<std::endl;
          response = ActivationReturnType::kRun;
        }
        switch (response)
        {
            
            case ara::exec::ActivationReturnType::kInit:
            {
                //FindService();
                break;
            }
            case ara::exec::ActivationReturnType::kRun:
            {
                //step();
                break;
            }
            case ara::exec::ActivationReturnType::kTerminate:
            {
                std::cout<< "ActivationReturnType::kTerminate"<<std::endl;
                WaitUntilTermination();
                break;
            }
            default:
            {
                break;
            }
        }
    }
	*/
	
	std::cout << "[IDC]::Run() After while(true)" << std::endl;
}

/* Test Automation Framework changes: Check received data size is correct*/
bool STUBCDCApplication::IsDataReceived() {
	if(is_data_size_correct && is_callback_received) {
		std::cout << "Correct data size received" << std::endl;
		
		return true;
	}
	
	std::cout << "Incorrect data size received" << std::endl;
	return false;
}

/* Test Automation Framework changes: Return GNS_time value*/
uint64_t STUBCDCApplication::gns_time() {
	std::cout << "GNS_time " << gns_time_ms << std::endl;
	return gns_time_ms;
}
