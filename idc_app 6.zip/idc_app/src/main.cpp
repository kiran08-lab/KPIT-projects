/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      main.cpp
 *   @brief     This file contains the class implementation
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#include <exception>
#include <cstdint>
#include <unistd.h>
#include <iostream>
#include <cstdlib>
#include <type_traits>
#include <ara/log/logmanager.h>
#include <ara/log/logging.h>
#include "IDC_app.h"
#include <csignal>

#include <ara/exec/execution_client.h>
#include "ara/core/initialization.h"

#ifdef __QNXNTO__
#include <sys/neutrino.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syspage.h>
#endif

using namespace ara::log;
//volatile static std::sig_atomic_t sig_value;

int ret_val;

void sig_handler (int signal)
{
    sig_value = signal;
	//app_terminate_flag = true;
}

int main()
{	
	std::cout << "Inside main():: SOLVE rpcServerClose()" << std::endl;

	/*Initialize signal handler*/
    //signal(SIGTERM, sig_handler);
    //signal(SIGINT, sig_handler);

	if(!ara::core::Initialize()) {
		std::cerr << "Initialization failed. Exiting." << std::endl;
		std::cout << "[IDC] Initialization failed. Exiting." << std::endl;
		return 1;
	}
	ara::log::Logger& logger{ara::log::CreateLogger("STB4", "SOMEIP_TCP_100KB_SER_TRUE", ara::log::LogLevel::kInfo)};
		
	ara::exec::ExecutionClient exec_client;
    exec_client.ReportExecutionState(ara::exec::ExecutionState::kRunning);
	
	//std::thread act1(ThreadAct1);	
   		
	std::this_thread::sleep_for(std::chrono::milliseconds(500));
	std::cout << "[IDC] IDCApp: Started ....." << std::endl;
	
    IDCApplication actSamp;
	ret_val = actSamp.Execute();		
	
	if(!ara::core::Deinitialize()) {
		std::cerr << "Deinitialize failed." << std::endl;
		std::cout << "[IDC] Deinitialize failed......" << std::endl;
		return 1;
	}	

	return ret_val;
}
