/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      STUB_CDC_app.cpp
 *   @brief     This file contains the class implementation
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#include <string>
#include <iostream>
#include <cstdint>
#include <unistd.h>
#include <csignal>
#include <cstdint>
#include <atomic>
#include <ara/log/logging.h>
#include <ara/exec/execution_client.h>
#include "IDC_app.h"
#include "ara/core/instance_specifier.h"
#include <chrono>
#include <sys/neutrino.h>
#include <ara/core/steady_clock.h>
#include <ara/core/result.h>
#include <ara/exec/exec_error_domain.h>
#define CC_TO_MICROS(clock_tick) (((clock_tick)*UINT64_C(1000000)) / (SYSPAGE_ENTRY(qtime)->cycles_per_sec))
#define DELTA_TO_NS(delta) ( ((delta) * UINT64_C(1000000000)) / (SYSPAGE_ENTRY(qtime)->cycles_per_sec) )
using ara::exec::ActivationReturnType;
using namespace ara::exec;

bool IDCApplication::is_data_size_correct = false;
bool IDCApplication::is_callback_received = false;

uint64_t IDCApplication::gns_time_ms = 0;

//#define SIZE_1MB 1048576 // define 1MB in bytes
#define SIZE_100KB 102400 // define 100KB in bytes

static  IDCCameraTransmissionInformationBusOut_STRUCTURE Rec_InfoCameradata{};
static  IDCRadarTransmissionInformationBusOut_STRUCTURE Rec_InfoRadardata{};
static  IDCVehicleTransmissionInformationBusOut_STRUCTURE Rec_InfoVehicledata{};
//static HDF2stubCDC_message vecRf5FsTimestampSec{};

IDCApplication::IDCApplication()
    : log_(ara::log::CreateLogger("STB6", "SOMEIP_TCP_100KB_SER_TRUE", ara::log::LogLevel::kVerbose))
{
}

bool IDCApplication::OnInitialize()
{
    std::cout << "[IDC] OnInitialize..." << std::endl;
    /* RadarSignal instanceSpecifier*/
    ara::core::InstanceSpecifier radarPortSpecifier{"Application/AdaptiveApplicationSwComponentTypes/IDC/RPort_ADAS_Acore_RadarSignal_Radar2IDCService"};
    std::cout << "[IDC] assigned Instance specifier..." << std::endl;
	auto instanceIDs_radar = ara::com::runtime::ResolveInstanceIDs(radarPortSpecifier);
	std::cout << "[IDC] InstanceSpecifier check for radar" << std::endl;
	if (instanceIDs_radar.Err().has_value()) 
	{
		log_.LogError()<<"Error : "<<instanceIDs_radar.Error();
        std::cout << "[IDC] error in instanceID" <<instanceIDs_radar.Error() << std::endl;
		//throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}
	ara::com::InstanceIdentifierContainer radarinstanceIDs = instanceIDs_radar.Value(); //extracting the instanceIDs wrapped in ara::core::Result
    std::cout << "[IDC] extracting instanceID" << std::endl;
	log_.LogInfo() << "Searching for Service Instance:" << radarinstanceIDs[0].ToString();//Continue operations with instanceIDs
    serviceInstanceRadar_ = radarinstanceIDs[0];
    log_.LogWarn() << "IDC APP OnInitialize instance is created for RadarSignal ";
    std::cout << "[IDC] IDC APP OnInitialize instance is created for RadarSignal" << std::endl;
	//std::this_thread::sleep_for(std::chrono::milliseconds(10000));//new change

    /* CameraSignal instanceSpecifier*/
    ara::core::InstanceSpecifier cameraportSpecifier{"Application/AdaptiveApplicationSwComponentTypes/IDC/RPort_ADAS_Acore_CameraSignal_Camera2IDCService"};
    auto instanceIDs_camera = ara::com::runtime::ResolveInstanceIDs(cameraportSpecifier);
	std::cout << "InstanceSpecifier check for camera" << std::endl;
    if (instanceIDs_camera.Err().has_value()) 
	{
		log_.LogError()<<"Error : "<<instanceIDs_camera.Error();
		//throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}
    ara::com::InstanceIdentifierContainer camerainstanceIDs = instanceIDs_camera.Value(); //extracting the instanceIDs wrapped in ara::core::Result
	log_.LogInfo() << "Searching for Service Instance:" << camerainstanceIDs[0].ToString();//Continue operations with instanceIDs
    serviceInstanceCamera_ = camerainstanceIDs[0];
    log_.LogWarn() << "IDC APP OnInitialize instance is created for CameraSignal";
    std::cout << "[IDC] IDC APP OnInitialize instance is created for CameraSignal" << std::endl;

    /* VehicleSignal instanceSpecifier*/
    ara::core::InstanceSpecifier vehicleportSpecifier{"Application/AdaptiveApplicationSwComponentTypes/IDC/RPort_ADAS_Acore_VehicleSignal_Vehicle2IDCService"};
    auto instanceIDs_vehicle = ara::com::runtime::ResolveInstanceIDs(vehicleportSpecifier);
	std::cout << "InstanceSpecifier check for vehicle" << std::endl;
    if (instanceIDs_vehicle.Err().has_value()) 
	{
		log_.LogError()<<"Error : "<<instanceIDs_vehicle.Error();
		//throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}
    ara::com::InstanceIdentifierContainer vehicleinstanceIDs = instanceIDs_vehicle.Value(); //extracting the instanceIDs wrapped in ara::core::Result
	log_.LogInfo() << "Searching for Service Instance:" << vehicleinstanceIDs[0].ToString();//Continue operations with instanceIDs
    serviceInstanceVehicle_ = vehicleinstanceIDs[0];
    log_.LogWarn() << "IDC APP OnInitialize instance is created for VehicleSignal";
    std::cout << "[IDC] IDC APP OnInitialize instance is created for VehicleSignal" << std::endl;

        /* daq instanceSpecifier*/
    ara::core::InstanceSpecifier daqPortSpecifier{"Application/AdaptiveApplicationSwComponentTypes/IDC/RPort_ADAS_ACore_IDC_CORE_DAQ_continual_Service"};
    std::cout << "[IDC] assigned Instance specifier..." << std::endl;
	auto instanceIDs_daq = ara::com::runtime::ResolveInstanceIDs(daqPortSpecifier);
	std::cout << "[IDC] InstanceSpecifier check for daq" << std::endl;
	if (instanceIDs_daq.Err().has_value()) 
	{
		log_.LogError()<<"Error : "<<instanceIDs_daq.Error();
        std::cout << "[IDC] error in instanceID" <<instanceIDs_daq.Error() << std::endl;
		//throw ara::com::IllegalStateException("Error returned from ResolveInstanceIDs");
	}
	ara::com::InstanceIdentifierContainer daqinstanceIDs = instanceIDs_daq.Value(); //extracting the instanceIDs wrapped in ara::core::Result
	log_.LogInfo() << "Searching for Service Instance:" << daqinstanceIDs[0].ToString();//Continue operations with instanceIDs
    serviceInstancedaq_ = daqinstanceIDs[0];
    log_.LogWarn() << "IDC APP OnInitialize instance is created for daq ";
    std::cout << "[IDC] IDC APP OnInitialize instance is created for daq" << std::endl;
    CORE_DAQ_continual_ServiceProxy::StartFindService (
    [this](ara::com::ServiceHandleContainer<CORE_DAQ_continual_ServiceProxy::HandleType> handles,
    ara::com::FindServiceHandle handler) {
    this->ServiceAvailabilityCallbackDaqContinualMethod (std::move(handles), handler);
    },ara::com::InstanceIdentifier(daqinstanceIDs[0]));
     std::cout<<"[IDC] Daq Findservice is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
	//std::this_thread::sleep_for(std::chrono::milliseconds(10000));//new change

    return true;
}

void IDCApplication::OnTerminate()
{
    log_.LogWarn() << "IDC Application terminating";
    std::cout << "[IDC] IDC Application terminating" << std::endl;
}

void IDCApplication::FindService()
{
    std::cout << "[IDC] start FindServices.." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    /*Radar signal*/
    ADAS_ACore_RadarSignal_SDD_ServiceProxy::StartFindService(
    [this](ara::com::ServiceHandleContainer<ADAS_ACore_RadarSignal_SDD_ServiceProxy::HandleType> handles,
    ara::com::FindServiceHandle handler)
    {
        serviceAvailabilityCallbackRadar(std::move(handles), handler);
    });
    std::cout<<"[IDC] Radar Findservice is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;

    /*Camera signal*/
    ADAS_ACore_CameraSignal_SDD_ServiceProxy::StartFindService(
    [this](ara::com::ServiceHandleContainer<ADAS_ACore_CameraSignal_SDD_ServiceProxy::HandleType> handles,
    ara::com::FindServiceHandle handler)
    {
        serviceAvailabilityCallbackCamera(std::move(handles), handler);
    });
    std::cout<<"[IDC] Camera Findservice is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;

    /*Vehicle signal*/
    ADAS_ACore_VehicleSignal_SDD_ServiceProxy::StartFindService(
    [this](ara::com::ServiceHandleContainer<ADAS_ACore_VehicleSignal_SDD_ServiceProxy::HandleType> handles,
    ara::com::FindServiceHandle handler)
    {
        serviceAvailabilityCallbackVehicle(std::move(handles), handler);
    });
    std::cout<<"[IDC] Vehicle Findservice is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;

    /*Daq service
    CORE_DAQ_continual_ServiceProxy::StartFindService (
    [this](ara::com::ServiceHandleContainer<CORE_DAQ_continual_ServiceProxy::HandleType> handles,
    ara::com::FindServiceHandle handler) {
    this->ServiceAvailabilityCallbackDaqContinualMethod (std::move(handles), handler);
    });
     std::cout<<"[IDC] Daq Findservice is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;*/

}

void IDCApplication::serviceAvailabilityCallbackRadar(ara::com::ServiceHandleContainer<ADAS_ACore_RadarSignal_SDD_ServiceProxy::HandleType> handles,
        ara::com::FindServiceHandle )
{
    std::cout << "[IDC] Callback received IDC, Found handles " << handles.size() << std::endl;

    if (0u < handles.size()) {
        std::cout<<"[IDC] inside radar if condition for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
        for (auto it : handles) {
        if (nullptr == radar_proxy_ && serviceInstanceRadar_ ==  static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "[IDC] radar GetInstanceId for SOMEIP_TCP_100KB_SER_TRUE = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetUpRadarProxy(handles[0]);   
            }
        }
    } else if ((0u == handles.size()) && this->radar_proxy_) {
        // previously registered handle is now no vehicleProxy present, reset proxy_
        this->radar_proxy_.reset();
    } else {
            std::cout<<"[IDC]radar handles.size() is 0 and proxy is not assigned"<<std::endl;
        // means handles.size() is 0 and proxy is not assigned, though this should not happen it's no problem
    }
    std::cout<<"[IDC] ServiceAvailabilitycallbackRadar is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
	is_callback_received = true;
    return;
}

void IDCApplication::SetUpRadarProxy(ADAS_ACore_RadarSignal_SDD_ServiceProxy::HandleType handle)
{
    this->radar_proxy_ = std::make_shared<ADAS_ACore_RadarSignal_SDD_ServiceProxy>(handle);
    this->radar_proxy_->ADAS_IDC_EVT.Subscribe(1);
    this->radar_proxy_->ADAS_IDC_EVT.SetReceiveHandler([this]() { ReceiveDataRadar(); });

    std::cout << "[IDC] IDCApplication::SetUpRadarProxy for SOMEIP_TCP_100KB_SER_TRUE"  << std::endl;

    if (this->radar_proxy_->ADAS_IDC_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    {
        std::cout << "[IDC] Subscribed successfully!!" << std::endl;
    }
    else
    {
        std::cout << "[IDC] Subscription failed!!" << std::endl;
    }
}

void IDCApplication::serviceAvailabilityCallbackCamera(ara::com::ServiceHandleContainer<ADAS_ACore_CameraSignal_SDD_ServiceProxy::HandleType> handles,
        ara::com::FindServiceHandle )
{
    std::cout << "[IDC] Camera Callback received IDC, Found handles " << handles.size() << std::endl;

    if (0u < handles.size()) {
        std::cout<<"[IDC] Camera inside if condition for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
        for (auto it : handles) {
        if (nullptr == camera_proxy_ && serviceInstanceCamera_ ==  static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "[IDC] Camera GetInstanceId for SOMEIP_TCP_100KB_SER_TRUE = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetUpCameraProxy(handles[0]);   
            }
        }
    } else if ((0u == handles.size()) && this->camera_proxy_) {
        // previously registered handle is now no vehicleProxy present, reset proxy_
        this->camera_proxy_.reset();
    } else {
            std::cout<<"[IDC] Camera handles.size() is 0 and proxy is not assigned"<<std::endl;
        // means handles.size() is 0 and proxy is not assigned, though this should not happen it's no problem
    }
    std::cout<<"[IDC] Camera ServiceAvailabilitycallbackCamera is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
	is_callback_received = true;
    return;
}

void IDCApplication::SetUpCameraProxy(ADAS_ACore_CameraSignal_SDD_ServiceProxy::HandleType handle)
{
    this->camera_proxy_= std::make_shared<ADAS_ACore_CameraSignal_SDD_ServiceProxy>(handle);
    this->camera_proxy_->ADAS_CAM_IDC_EVT.Subscribe(1);
    this->camera_proxy_->ADAS_CAM_IDC_EVT.SetReceiveHandler([this]() { ReceiveDataCamera(); });

    std::cout << "[IDC] Camera IDCApplication::SetUpCameraProxy for SOMEIP_TCP_100KB_SER_TRUE"  << std::endl;

    if (this->camera_proxy_->ADAS_CAM_IDC_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    {
        std::cout << "[IDC] Camera Subscribed successfully!!" << std::endl;
    }
    else
    {
        std::cout << "[IDC] Camera Subscription failed!!" << std::endl;
    }
}

void IDCApplication::serviceAvailabilityCallbackVehicle(ara::com::ServiceHandleContainer<ADAS_ACore_VehicleSignal_SDD_ServiceProxy::HandleType> handles,
        ara::com::FindServiceHandle )
{
    std::cout << "[IDC] Vehicle Callback received IDC, Found handles " << handles.size() << std::endl;

    if (0u < handles.size()) {
        std::cout<<"[IDC] Vehicle inside if condition for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
        for (auto it : handles) {
        if (nullptr == vehicle_proxy_ && serviceInstanceVehicle_ ==  static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "[IDC] Vehicle GetInstanceId for SOMEIP_TCP_100KB_SER_TRUE = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetUpVehicleProxy(handles[0]);   
            }
        }
    } else if ((0u == handles.size()) && this->vehicle_proxy_) {
        // previously registered handle is now no vehicleProxy present, reset proxy_
        this->vehicle_proxy_.reset();
    } else {
            std::cout<<"[IDC] Vehicle handles.size() is 0 and proxy is not assigned"<<std::endl;
        // means handles.size() is 0 and proxy is not assigned, though this should not happen it's no problem
    }
    std::cout<<"[IDC] Vehicle ServiceAvailabilityCallbackVehicle is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
	is_callback_received = true;
    return;
}

void IDCApplication::SetUpVehicleProxy(ADAS_ACore_VehicleSignal_SDD_ServiceProxy::HandleType handle)
{
    this->vehicle_proxy_= std::make_shared<ADAS_ACore_VehicleSignal_SDD_ServiceProxy>(handle);
    this->vehicle_proxy_->ADAS_VEHICLE_IDC_EVT.Subscribe(1);
    this->vehicle_proxy_->ADAS_VEHICLE_IDC_EVT.SetReceiveHandler([this]() { ReceiveDataVehicle(); });

    std::cout << "[IDC] Vehicle IDCApplication::SetUpVehicleProxy for SOMEIP_TCP_100KB_SER_TRUE"  << std::endl;

    if (this->vehicle_proxy_->ADAS_VEHICLE_IDC_EVT.GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed)
    {
        std::cout << "[IDC] Vehicle Subscribed successfully!!" << std::endl;
    }
    else
    {
        std::cout << "[IDC] Vehicle Subscription failed!!" << std::endl;
    }
}

void IDCApplication::ServiceAvailabilityCallbackDaqContinualMethod(ara::com::ServiceHandleContainer<CORE_DAQ_continual_ServiceProxy::HandleType> handles,
        ara::com::FindServiceHandle )
{
    /* DAQ Continual method subscription. */
    if (0u < handles.size()) {
        std::cout<<"[IDC] Daq inside if condition for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
        for (auto it : handles) {
            if (nullptr == daq_proxy_ && serviceInstancedaq_ == static_cast<uint16_t>(it.GetInstanceId())) {
                std::cout << "[IDC] Daq GetInstanceId for SOMEIP_TCP_100KB_SER_TRUE = "<< static_cast<uint16_t>(it.GetInstanceId()) << std::endl;
                SetupDaqContinualMethodProxy (handles[0]);
            }
        }
    }
     else if ((0u == handles.size()) && this->daq_proxy_) {
        this->daq_proxy_.reset();
    }
    else {
       std::cout<<"[IDC] Daq handles.size() is 0 and proxy is not assigned"<<std::endl;
    }
    std::cout<<"[IDC] Daq ServiceAvailabilityCallbackVehicle is completed for SOMEIP_TCP_100KB_SER_TRUE"<<std::endl;
	is_callback_received = true;
    return;
}

void IDCApplication::SetupDaqContinualMethodProxy(CORE_DAQ_continual_ServiceProxy::HandleType handle) {
    /* Make shared daq continual proxy*/
    this->daq_proxy_= std::make_shared<CORE_DAQ_continual_ServiceProxy>(handle);
    //LOGGER_INFO("[HPROBE1] Created DAQ continual method proxy from handle with instance:  {}",static_cast<uint16_t>(this->serviceInstancedaq_.GetHandle().GetInstanceId()));
    SendDaqData();
}

void IDCApplication::ReceiveDataRadar()
{
   std::cout << "[IDC] Radar inside the Received" << std::endl;
	uint64_t GNS_start = ClockCycles();
	
	std::size_t received_data = 0;
	
    auto callback = [this ,GNS_start, &received_data](auto sample)
    {
		uint64_t GNS_time = CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(GNS_start);
		
		std::cout << "[IDC] Radar GNS time in micro seconds "<< GNS_time << std::endl;
		
		std::cout << "[IDC] Radar Received data in subscriber for SOMEIP_TCP_100KB_SER_TRUE: " << sizeof(*sample)<< std::endl;
		
		received_data = sizeof(*sample);
		gns_time_ms = GNS_time;
	};
	
    this->radar_proxy_->ADAS_IDC_EVT.GetNewSamples(callback, 1);	
	
	if(received_data == SIZE_100KB) {
		is_data_size_correct = true;
	}
	
//     this->pm_proxy_->ADAS_CDC_EVT.Cleanup();
}

void IDCApplication::ReceiveDataCamera()
{
   std::cout << "[IDC] Camera inside the Received" << std::endl;
	uint64_t GNS_start = ClockCycles();
	
	std::size_t received_data = 0;
	
    auto callback = [this ,GNS_start, &received_data](auto sample)
    {
		uint64_t GNS_time = CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(GNS_start);
		
		std::cout << "[IDC] Camera GNS time in micro seconds "<< GNS_time << std::endl;
		
		std::cout << "[IDC] Camera Received data in subscriber for SOMEIP_TCP_100KB_SER_TRUE: " << sizeof(*sample)<< std::endl;
		
		received_data = sizeof(*sample);
		gns_time_ms = GNS_time;
	};
	
    this->camera_proxy_->ADAS_CAM_IDC_EVT.GetNewSamples(callback, 1);	
	
	if(received_data == SIZE_100KB) {
		is_data_size_correct = true;
	}
	
//     this->pm_proxy_->ADAS_CDC_EVT.Cleanup();
}

void IDCApplication::ReceiveDataVehicle()
{
   std::cout << "[IDC] Vehicle inside the Received" << std::endl;
	uint64_t GNS_start = ClockCycles();
	
	std::size_t received_data = 0;
	
    auto callback = [this ,GNS_start, &received_data](auto sample)
    {
		uint64_t GNS_time = CC_TO_MICROS(ClockCycles()) - CC_TO_MICROS(GNS_start);
		
		std::cout << "[IDC] Vehicle GNS time in micro seconds "<< GNS_time << std::endl;
		
		std::cout << "[IDC] Vehicle Received data in subscriber for SOMEIP_TCP_100KB_SER_TRUE: " << sizeof(*sample)<< std::endl;
		
		received_data = sizeof(*sample);
		gns_time_ms = GNS_time;
	};
	
    this->vehicle_proxy_->ADAS_VEHICLE_IDC_EVT.GetNewSamples(callback, 1);	
	
	if(received_data == SIZE_100KB) {
		is_data_size_correct = true;
	}
	
//     this->pm_proxy_->ADAS_CDC_EVT.Cleanup();
}

void IDCApplication::SendDaqData()
{
    if (daq_proxy_ == nullptr) {
        std::cout << "[IDC] DAQ proxy is NULL" << std::endl;
        return;
    }

    Honda::DAQ::core_daq_continual_service_::TransmissionInformation_STRUCTURE* data{};

    // Fill mandatory fields (example)
    data->uedClientId = 0x01;
    data->uedPduId = 0x12345678;
    data->uedDataVector.resize(8, 0xAA); // dummy payload

    //API call
    daq_proxy_->DAQ_UNIVERSAL_ETH_DATA_FIR_FGT(*data);

    std::cout << "[IDC] DAQ data sent successfully" << std::endl;
}

// Model step function
void IDCApplication::step()
{
    if (is_data_received_)
    {
        Rec_InfoRadardata = Rec_RadarData;  
        Rec_InfoCameradata = Rec_CameraData;
        Rec_InfoVehicledata = Rec_VehicleData;  
    }
}

// This method contains the implementation required for the DEterministic client and Runworkerpool
void IDCApplication::Run()
{
    //mkfifo("./run/sysstate-client-fifo", 0666);
	FindService();
	WaitUntilTermination();
	//system("rm -rf ./run/sysstate-client-fifo");
	/*
    ara::exec::ActivationReturnType response;
	ara::core::Result<ActivationReturnType> waitForRet_ = ara::core::Result<ActivationReturnType>::FromError(ExecErrc::kFailed);
    ara::exec::DeterministicClient deterministic;
    
	//while (app_terminate_flag == false)
	
    while (sig_value == 0)
    {
	   waitForRet_= deterministic.WaitForActivation();
	   if (waitForRet_.HasValue()) 
		{
          response = waitForRet_.Value();
        } else
		{
          std::cout << " Wait for Activation returned Error condition "<< waitForRet_.Error()<<std::endl;
          response = ActivationReturnType::kRun;
        }
        switch (response)
        {
            
            case ara::exec::ActivationReturnType::kInit:
            {
                //FindService();
                break;
            }
            case ara::exec::ActivationReturnType::kRun:
            {
                //step();
                break;
            }
            case ara::exec::ActivationReturnType::kTerminate:
            {
                std::cout<< "ActivationReturnType::kTerminate"<<std::endl;
                WaitUntilTermination();
                break;
            }
            default:
            {
                break;
            }
        }
    }
	*/
	
	std::cout << "[IDC] IDCApplication::Run() After while(true)" << std::endl;
}

/* Test Automation Framework changes: Check received data size is correct*/
bool IDCApplication::IsDataReceived() {
	if(is_data_size_correct && is_callback_received) {
		std::cout << "[IDC] Correct data size received" << std::endl;
		
		return true;
	}
	
	std::cout << "[IDC] Incorrect data size received" << std::endl;
	return false;
}

/* Test Automation Framework changes: Return GNS_time value*/
uint64_t IDCApplication::gns_time() {
	std::cout << "[IDC] GNS_time " << gns_time_ms << std::endl;
	return gns_time_ms;
}
