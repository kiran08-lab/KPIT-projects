/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      adaptive_app.cpp
 *   @brief     This file contains the class implementation
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#include <unistd.h>
#include <csignal>
#include <cstdint>
#include <atomic>
#include <ara/log/logging.h>
#include <ara/exec/execution_client.h>
#include "../inc/adaptive_app.h"


int AdaptiveApplication::selfpipe[2] = {0, 0};

std::atomic_bool AdaptiveApplication::exit_requested_(false);

void AdaptiveApplication::SigTermHandler(const int sig)
{
    if (sig == SIGTERM) {
    	exit_requested_ = true;
    	if (-1 == write(selfpipe[PipeWritingEnd], "\0", 1)) {
    	}
    }
}

bool AdaptiveApplication::OnInitialize()
{
    return true;
}

void AdaptiveApplication::OnTerminate()
{}

void AdaptiveApplication::WaitUntilTermination()
{
	std::cout << "Inside the WaitUntilTermination" <<std::endl;
    while (!exit_requested_) {
        int buffer;
        // Blocking read on selfpipe_
        ssize_t bytesRead(read(selfpipe[PipeReadingEnd], &buffer, sizeof(int)));
        if (bytesRead > 0) {
        	// selfpipe_ is only used to signal an exit request.
        	exit_requested_ = true;
        } else {
        	 log_.LogError() << "Execution stopped. Unable to read";
        }
    }
	std::cout << "Inside the WaitUntilTermination end" << std::endl;
}

void AdaptiveApplication::ReportRunningState()
{
    ara::exec::ExecutionClient exec_client;
    exec_client.ReportExecutionState(ara::exec::ExecutionState::kRunning);
}

int AdaptiveApplication::Execute()
{
    if (Initialize()) {
        Run();
        Terminate();
        return EXIT_SUCCESS;
    }
    return EXIT_FAILURE;
}

bool AdaptiveApplication::Initialize()
{
    if (!OnInitialize())
        return false;
    // Creating a pipe
    if (pipe(selfpipe) == -1) {
        // Could not create a pipe for performing a classic self pipe trick
        log_.LogError() << "Execution stopped. Unable to create a pipe";
        return false;
    }
    struct sigaction sa;
    sa.sa_handler = SigTermHandler;
    sa.sa_flags = 0;
    sigemptyset(&sa.sa_mask);
    // register signal handler
    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        // Could not register a SIGTERM signal handler
        log_.LogError() << "Execution stopped. Unable to register signal handler";
        CloseSelfPipe();
        return false;
    }
    return true;
}

void AdaptiveApplication::ReportTerminatingState()
{
    ara::exec::ExecutionClient exec_client;
    exec_client.ReportExecutionState(ara::exec::ExecutionState::kTerminating);
}

void AdaptiveApplication::Terminate()
{
    ReportTerminatingState();
    OnTerminate();
    CloseSelfPipe();
}

void AdaptiveApplication::CloseSelfPipe()
{
    close(selfpipe[PipeReadingEnd]);
    close(selfpipe[PipeWritingEnd]);
}
