/**
 *
 *  @copyright  (C) KPIT Technologies Limited
 *              Created in 2018 as an unpublished copyright work.
 *               All rights reserved.
 *              KPIT Technologies Limited owns all the rights to this work.This
 *              work shall not be copied, reproduced, used, modified or its information
 *              disclosed without the prior written authorization of KPIT Technologies
 *              Limited.
 *   @file      STUB_CDC_app.h
 *   @brief     This file contains the method declaration
 *   @details
 *   @version   Revision 1.0
 *   @date
 *   @bug --
 *   @warning --
*/
#ifndef IDCAPP_H
#define IDCAPP_H

#include <map>
#include <memory>
#include <iostream>
#include <unistd.h>
#include <atomic>
#include <ara/log/logging.h>
#include <ara/core/future.h>
#include <ara/core/promise.h>
#include "honda/radarsignal/adas_acore_radarsignal_sdd_service_proxy.h"
#include "honda/radarsignal/adas_acore_radarsignal_sdd_service_common.h"
#include "honda/camerasignal/adas_acore_camerasignal_sdd_service_proxy.h"
#include "honda/camerasignal/adas_acore_camerasignal_sdd_service_common.h"
#include "honda/vehiclesignal/adas_acore_vehiclesignal_sdd_service_proxy.h"
#include "honda/vehiclesignal/adas_acore_vehiclesignal_sdd_service_common.h"
#include "honda/daq/core_daq_continual_service_proxy.h"
#include "honda/daq/core_daq_continual_service_common.h"
#include "../inc/adaptive_app.h"

#include <ara/exec/deterministic_client.h>
#include <ara/exec/execution_client.h>

#include "impl_type_idcradartransmissioninformationbusout_structure.h"
#include "impl_type_idccameratransmissioninformationbusout_structure.h"
#include "impl_type_idcvehicletransmissioninformationbusout_structure.h"

volatile static std::sig_atomic_t sig_value;

using Honda::RadarSignal::proxy::ADAS_ACore_RadarSignal_SDD_ServiceProxy;
using Honda::CameraSignal::proxy::ADAS_ACore_CameraSignal_SDD_ServiceProxy;
using Honda::VehicleSignal::proxy::ADAS_ACore_VehicleSignal_SDD_ServiceProxy;
using Honda::DAQ::proxy::CORE_DAQ_continual_ServiceProxy;

using ara::com::InstanceIdentifier;
	
/// @brief This class represents
/// DataIdentifer Application
class IDCApplication final : public AdaptiveApplication
{

public:
    
	IDCApplication();

	IDCApplication(const IDCApplication&) = delete;

	IDCApplication& operator=(const IDCApplication&) = delete;

	IDCApplication(IDCApplication&&) = delete;

	IDCApplication& operator=(IDCApplication&&) = delete;

    ~IDCApplication() = default;

	uint16_t serviceInstanceRadar_;
	uint16_t serviceInstanceCamera_;
	uint16_t serviceInstanceVehicle_;
	uint16_t serviceInstancedaq_;

    void FindService();	
	
	void serviceAvailabilityCallbackRadar(ara::com::ServiceHandleContainer<ADAS_ACore_RadarSignal_SDD_ServiceProxy::HandleType> handles, ara::com::FindServiceHandle );
	void SetUpRadarProxy(Honda::RadarSignal::proxy::ADAS_ACore_RadarSignal_SDD_ServiceProxy::HandleType handle);
	std::shared_ptr<Honda::RadarSignal::proxy::ADAS_ACore_RadarSignal_SDD_ServiceProxy> radar_proxy_ = nullptr;
	void ReceiveDataRadar(void);

	void serviceAvailabilityCallbackCamera(ara::com::ServiceHandleContainer<ADAS_ACore_CameraSignal_SDD_ServiceProxy::HandleType> handles, ara::com::FindServiceHandle );
	void SetUpCameraProxy(Honda::CameraSignal::proxy::ADAS_ACore_CameraSignal_SDD_ServiceProxy::HandleType handle);
	std::shared_ptr<Honda::CameraSignal::proxy::ADAS_ACore_CameraSignal_SDD_ServiceProxy> camera_proxy_ = nullptr;
	void ReceiveDataCamera(void);

	void serviceAvailabilityCallbackVehicle(ara::com::ServiceHandleContainer<ADAS_ACore_VehicleSignal_SDD_ServiceProxy::HandleType> handles, ara::com::FindServiceHandle );
	void SetUpVehicleProxy(Honda::VehicleSignal::proxy::ADAS_ACore_VehicleSignal_SDD_ServiceProxy::HandleType handle);
	std::shared_ptr<Honda::VehicleSignal::proxy::ADAS_ACore_VehicleSignal_SDD_ServiceProxy> vehicle_proxy_ = nullptr;
	void ReceiveDataVehicle(void);

	void ServiceAvailabilityCallbackDaqContinualMethod(ara::com::ServiceHandleContainer<CORE_DAQ_continual_ServiceProxy::HandleType> handles, ara::com::FindServiceHandle);
	void SetupDaqContinualMethodProxy(Honda::DAQ::proxy::CORE_DAQ_continual_ServiceProxy::HandleType handle);
	std::shared_ptr<Honda::DAQ::proxy::CORE_DAQ_continual_ServiceProxy> daq_proxy_ = nullptr;
	void SendDaqData();
	// model step function
    void step();
	void act();
	
	static bool IsDataReceived();
	static uint64_t gns_time();
	
protected:
    bool OnInitialize() override;
    void Run() override;
    void OnTerminate() override;
	
private:
	static uint64_t gns_time_ms;
	static bool is_data_size_correct;
	static bool is_callback_received;
    ara::log::Logger& log_;
	bool is_data_received_=false;
	IDCRadarTransmissionInformationBusOut_STRUCTURE Rec_RadarData{};
	IDCCameraTransmissionInformationBusOut_STRUCTURE Rec_CameraData{};
	IDCVehicleTransmissionInformationBusOut_STRUCTURE Rec_VehicleData{};
	

};

#endif // DIDAPP_H
