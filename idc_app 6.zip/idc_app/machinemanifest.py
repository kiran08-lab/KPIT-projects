# from pyutil import filereplace
import os
import json

file_dir_list = []
file_dir = os.getcwd()
f = open("config.json")
loaded_data = json.load(f)

print("loaded_data---",loaded_data)

for subdir, dirs, files in os.walk(file_dir):
    for file in files:
        if file.lower().endswith(('.arxml', '.yml' , '.txt')):
            file_dir_list.append(os.path.join(subdir, file))

# for files in file_dir_list:
#     for keys1, values1 in loaded_data.items():
#         file_replaced = filereplace(files,keys1,values1)
   
for files in file_dir_list:
    for keys1, values1 in loaded_data.items():
        try:
            with open(files, "r+") as text_file:
                texts = text_file.read()
                texts = texts.replace(keys1, values1)
            with open(files, "w") as text_file:
                text_file.write(texts)
        except FileNotFoundError as f:
            print("Could not find the file you are trying to read.")


