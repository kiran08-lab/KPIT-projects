This folder contains Library files.
