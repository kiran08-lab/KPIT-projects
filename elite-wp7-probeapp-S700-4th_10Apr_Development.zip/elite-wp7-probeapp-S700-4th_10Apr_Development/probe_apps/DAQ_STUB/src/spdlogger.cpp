
#include <fstream>
#include <iostream>
#include <filesystem>
#include <signal.h>
#include "spdlog/async.h"
#include "spdlog/sinks/basic_file_sink.h"
#include "spdlog/sinks/rotating_file_sink.h"
#include "spdlogger.h"

// CONFIG STRING
#define SPDLOGGER_LOGLEVEL_STRING       "LogLevel"
#define SPDLOGGER_DIRECTORYPATH_STRING  "directoryPath"
#define SPDLOGGER_MAXSIZE_STRING        "maxSize"
#define SPDLOGGER_MAXFILES_STRING       "maxFiles"
#define SPDLOGGER_QUEUESIZE_STRING      "queueSize"
#define SPDLOGGER_THREADS_STRING        "Threads"
#define SPDLOGGER_SIGNALHANDLER         "SignalHandler"

// DEFAULT CONFIG
#define SPDLOGGER_CONFIGFILEPATH                "/var/spdlog/SpdlogConfig.cfg" // configfile path
#define SPDLOGGER_DEFAULT_LOGLEVEL              spdlog::level::info            // default logLevel
#define SPDLOGGER_DEFAULT_DIRECTORYPATH         "/var/spdlog/log"              // default directoryPath
#define SPDLOGGER_DEFAULT_MAXSIZE               1024*1024*10                   // default maxSize(10MB=10240KB)
#define SPDLOGGER_DEFAULT_MAXFILES              5                              // default maxFiles
#define SPDLOGGER_DEFAULT_QUEUESIZE             8192                           // default queueSize
#define SPDLOGGER_DEFAULT_THREADS               1                              // default threads
#define SPDLOGGER_DEFAULT_SIGNALHANDLERFLAG     1                              // default signalHandlerFlag

// MAX and MIN CONFIG
#define SPDLOGGER_MAX_LOGLEVEL              spdlog::level::off          // max maxSize
#define SPDLOGGER_MIN_LOGLEVEL              spdlog::level::debug        // min maxSize
#define SPDLOGGER_MAX_MAXSIZE               1024 * 1024 * 100           // max maxSize(100MB=102400KB)
#define SPDLOGGER_MIN_MAXSIZE               1                           // min maxSize
#define SPDLOGGER_MAX_MAXFILES              10                          // max maxFiles
#define SPDLOGGER_MIN_MAXFILES              1                           // min maxFiles
#define SPDLOGGER_MAX_QUEUESIZE             1024 * 10                   // max queueSize
#define SPDLOGGER_MIN_QUEUESIZE             1                           // min queueSize
#define SPDLOGGER_MAX_THREADS               2                           // max threads
#define SPDLOGGER_MIN_THREADS               1                           // min threads

// FLAG CONFIG
#define SPDLOGGER_OFF_SIGNALHANDLERFLAG     0                           // off signalHandler
#define SPDLOGGER_ON_SIGNALHANDLERFLAG      1                           // on  signalHandler

#define SIGNAL_ERROR -1                                                 // sigaction error


/**
* @fn		  checkSpdlogConfig
* @brief	  Check logging configuration
* @param[in,out]		logLevel		        log level
* @param[in,out]		directoryPath		    logdirectory path
* @param[in,out]		maxSize				      maximum log file size
* @param[in,out]		maxFiles			      maximum number of log files
* @param[in,out]		queueSize				    Threadpool que size
* @param[in,out]		Threads				      Threadpool threads num
* @param[in,out]		signalhandler_flag	SignalHandler setting flag
* @return	  none
*/
void checkSpdlogConfig(
  spdlog::level::level_enum &logLevel,
  std::string &directoryPath,
  int &maxSize,
  int &maxFiles,
  int &queueSize,
  int &Threads,
  int &signalhandler_flag) {
    // LOGLEVEL CHECK
    if((logLevel < SPDLOGGER_MIN_LOGLEVEL) ||
         (logLevel > SPDLOGGER_MAX_LOGLEVEL)) {
        logLevel = SPDLOGGER_DEFAULT_LOGLEVEL;
    }
    else if((logLevel == spdlog::level::trace) ||
            (logLevel == spdlog::level::warn)) {
        logLevel = SPDLOGGER_DEFAULT_LOGLEVEL;
    }
    // DIRECTORY PATH CHECK
    std::string dummyname = directoryPath + "/spdlog_dumy.txt";
    std::ofstream outfile(dummyname, std::ios::out); 
    if (outfile.is_open()) {
        outfile.close();
        remove(dummyname.c_str());
    }else{
        directoryPath = SPDLOGGER_DEFAULT_DIRECTORYPATH;
    }
    // FILESIZE CHECK
    if((maxSize < SPDLOGGER_MIN_MAXSIZE) ||
       (maxSize > SPDLOGGER_MAX_MAXSIZE)) {
        maxSize = SPDLOGGER_DEFAULT_MAXSIZE;
    }
    // FILENUM CHECK 
    if((maxFiles < SPDLOGGER_MIN_MAXFILES) ||
       (maxFiles > SPDLOGGER_MAX_MAXFILES)) {
        maxFiles = SPDLOGGER_DEFAULT_MAXFILES;
    }
    // THREADPOOL QUEUESIZE CHECK
    if((queueSize < SPDLOGGER_MIN_QUEUESIZE) ||
       (queueSize > SPDLOGGER_MAX_QUEUESIZE)) {
        queueSize = SPDLOGGER_DEFAULT_QUEUESIZE;
    }
    // THREADPOOL THREADSNUM CHECK
    if((Threads < SPDLOGGER_MIN_THREADS) ||
       (Threads > SPDLOGGER_MAX_THREADS)) {
        Threads = SPDLOGGER_DEFAULT_THREADS;
    }
    // SIGNALHANDLER FLAG CHECK
    if((signalhandler_flag != SPDLOGGER_OFF_SIGNALHANDLERFLAG) &&
         (signalhandler_flag != SPDLOGGER_ON_SIGNALHANDLERFLAG)) {
        signalhandler_flag = SPDLOGGER_DEFAULT_SIGNALHANDLERFLAG;
    }
    return;
}

/** 
* @fn		  readSpdlogConfig
* @brief	  Read logging configuration file
* @param[in,out]		logLevel		        log level
* @param[in,out]		directoryPath		    file path
* @param[in,out]		maxSize				      maximum log file size
* @param[in,out]		maxFiles			      maximum number of log files
* @param[in,out]		queueSize				    Threadpool que size
* @param[in,out]		Threads				      Threadpool threads num
* @param[in,out]		signalhandler_flag	SignalHandler setting flag
* @return	  none
*/
void readSpdlogConfig(
  spdlog::level::level_enum &logLevel,
  std::string &directoryPath,
  int &maxSize,
  int &maxFiles,
  int &queueSize,
  int &Threads,
  int &signalhandler_flag) {
  
    std::string cfgFileName = SPDLOGGER_CONFIGFILEPATH;
    std::ifstream is(cfgFileName);
    if(!is.fail()) {
        std::string line;
        while(getline(is, line)) {
            if((line.length() > 0) && (line[0] == '#')) {
                continue;
            }
            size_t index = line.find("=");
            if(std::string::npos != index) {
                if(line.substr(0, index) == SPDLOGGER_LOGLEVEL_STRING) {
                    logLevel = static_cast<spdlog::level::level_enum>(
                        stoi(line.substr(index + 1)));
                }
                else if(line.substr(0, index) == SPDLOGGER_MAXFILES_STRING) {
                    maxFiles = stoi(line.substr(index + 1));
                }
                else if(line.substr(0, index) == SPDLOGGER_MAXSIZE_STRING) {
                    maxSize = stoi(line.substr(index + 1)) * 1024;
                }
                else if(line.substr(0, index) == SPDLOGGER_DIRECTORYPATH_STRING) {
                    directoryPath = line.substr(index + 1);
                    if(directoryPath.find("\n")) {
                        directoryPath.erase(
                          std::remove(directoryPath.begin(), directoryPath.end(), '\n'),
                          directoryPath.end());
                    }
                    if(directoryPath.find("\r")) {
                        directoryPath.erase(
                          std::remove(directoryPath.begin(), directoryPath.end(), '\r'),
                          directoryPath.end());
                    }
                }
                else if(line.substr(0, index) == SPDLOGGER_QUEUESIZE_STRING) {
                    queueSize = stoi(line.substr(index + 1));
                }
                else if(line.substr(0, index) == SPDLOGGER_THREADS_STRING) {
                    Threads = stoi(line.substr(index + 1));
                }
                else if(line.substr(0, index) == SPDLOGGER_SIGNALHANDLER) {
                    signalhandler_flag = stoi(line.substr(index + 1));
                }
            }
        }
    }
    else{
        logLevel = spdlog::level::off;
    }
    return;
}

/**
* @fn			sigHandler
* @brief		signal handler
* @param		signo		signal no
* @return	  none
*/
void sigHandler_(int signo) {
    LOGGER_INFO("sigHandler Start");
    if ((signo == SIGSEGV) || (signo == SIGIOT)) {
        LOGGER_INFO("SIGSEGV or SIGIOT");
        spdlog::get(DEFAULT_LOGGER)->dump_backtrace();
        spdlog::get(DEFAULT_LOGGER)->flush();
        spdlog::get(ERROR_LOGGER)->flush();
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    else {
        LOGGER_INFO("received signo : {}" ,std::to_string(signo));
    }
    return;
}

/** 
* @fn			    setSodlogConfig
* @brief	    Set up logging configuration for the exam
* @param[in]  appname   APP name
* @return	    none
*/
void setSpdlogConfig(std::string appname) {
    spdlog::level::level_enum logLevel = SPDLOGGER_DEFAULT_LOGLEVEL;  //LogLevel
    std::string directoryPath = SPDLOGGER_DEFAULT_DIRECTORYPATH;      //Directory Path
    int maxsize = SPDLOGGER_DEFAULT_MAXSIZE;                          //Log File Size
    int maxfiles = SPDLOGGER_DEFAULT_MAXFILES;                        //Log File Num
    int queuesize = SPDLOGGER_DEFAULT_QUEUESIZE;                      //Threadpool QueSize
    int threads = SPDLOGGER_DEFAULT_THREADS;                          //Threadpool Threads Num 
    int signalhandler_flag = SPDLOGGER_DEFAULT_SIGNALHANDLERFLAG;     //SignalHandler setting flag

    // Read ConfigFile
    readSpdlogConfig(logLevel, directoryPath, maxsize, maxfiles, queuesize, threads, signalhandler_flag);

    // Check Config
    checkSpdlogConfig(logLevel, directoryPath, maxsize, maxfiles, queuesize, threads, signalhandler_flag);

    // Threadpool Setting
    spdlog::init_thread_pool(queuesize, threads);
    
    spdlog::flush_on(spdlog::level::info);
    
    // ---default logger setting---//
    // default log path
    std::string defaultPath = directoryPath + "/trace_" + appname +".log";
    // make logger
    auto async_file = spdlog::rotating_logger_mt<spdlog::async_factory>(DEFAULT_LOGGER, defaultPath, maxsize, maxfiles);
    // loglevel setting
    async_file->set_level(logLevel);
    // format setting
    async_file->set_pattern("[%Y/%m/%d %H:%M:%S.%f][%L] %v");
    // default logger setting
    spdlog::set_default_logger(async_file);

    // ---error logger setting---//
    // error log path
    std::string errPath = directoryPath + "/error_" + appname +".log";
    // make error logger
    auto error_logger = spdlog::rotating_logger_mt<spdlog::async_factory>(ERROR_LOGGER, errPath, maxsize, maxfiles);
    // loglevel setting
    error_logger->set_level(spdlog::level::err);
    // format setting
    error_logger->set_pattern("[%Y/%m/%d %H:%M:%S.%f][%L][%g:%#:%!] %v");

    // signal handler setting
    if((logLevel != spdlog::level::off) && (signalhandler_flag != SPDLOGGER_OFF_SIGNALHANDLERFLAG)) {
        struct sigaction act;
        act.sa_handler = sigHandler_;
        act.sa_flags = SA_RESETHAND;
        if (sigaction(SIGSEGV, &act, NULL) == SIGNAL_ERROR) {
             std::cout << "[" << appname << "]can't catch SIGSEGV" << std::endl;
        }
        else {
             LOGGER_INFO("[{}]Signal handler set successfully(SIGSEGV)",appname);
        }
    
        if (sigaction(SIGIOT, &act, NULL) == SIGNAL_ERROR) {
             std::cout << "[" << appname << "]can't catch SIGIOT" << std::endl;
        }
        else {
             LOGGER_INFO("[{}]Signal handler set successfully(SIGIOT)",appname);
        }
        async_file->enable_backtrace(32);
    }

    return;
}


