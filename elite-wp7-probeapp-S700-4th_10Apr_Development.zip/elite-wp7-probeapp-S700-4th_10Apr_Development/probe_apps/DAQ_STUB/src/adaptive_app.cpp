// @copyright  (C) KPIT Technologies Limited
//             Created in 2022 as an unpublished copyright work.
//              All rights reserved.
//             KPIT Technologies Limited owns all the rights to this work.This
//             work shall not be copied, reproduced, used, modified or its information
//             disclosed without the prior written authorization of KPIT Technologies
//             Limited.
//  @file      adaptive_app.cpp
//  @brief     This file contains the class implementation
//  @details
//  @version   Revision 1.0
//  @date
//  @bug --
//  @warning --

#include "../inc/adaptive_app.h"

#include <ara/exec/execution_client.h>
#include <unistd.h>

#include <atomic>
#include <cstdint>
#include <array>

// @brief adaptive namespace
namespace adaptive
{

constexpr std::int32_t kByteZero{0};
constexpr std::int32_t kSigTerm{15};
constexpr std::int8_t kByte2{2};
constexpr std::int64_t kSocketClose{-1};

/* @brief Self Pipe used for read and write. */
std::array<int32_t, kByte2> AdaptiveApplication::selfPipe_{kByteZero, kByteZero};

/* @brief Stores exit requested status. */
std::atomic_bool AdaptiveApplication::exitRequested_{false};

/* @brief Handles the SIGTERM signals. */
/* @param sig Stores Signals value. */
void AdaptiveApplication::SigTermHandler(std::int32_t const sig)
{
    if (sig == kSigTerm)
    {
        constexpr std::size_t kByte1{1U};
        exitRequested_ = true;
        if (kSocketClose == write(selfPipe_[kPipeWritingEnd_], "\0", (kByte1)))
        {
        }
    }
}

/* @brief Checks whether exit is requested for the AdaptiveApplication. */
void AdaptiveApplication::WaitUntilTermination()
{
    LOGGER_INFO("AdaptiveApplication::WaitUntilTermination. ExitRequested Status : {}",exitRequested_);
    while (!exitRequested_)
    {
        std::int64_t buffer;

        /* Blocking read on selfpipe_ */
        std::int64_t const kBytesRead{read(selfPipe_[kPipeReadingEnd_], &buffer,
                                           sizeof(std::int64_t))};
        constexpr std::int64_t kZero{0};

        if (buffer == kZero)
        {
            LOGGER_ERROR("No Data to read");
        }

        if (kBytesRead > kZero)
        {
            /* selfpipe_ is only used to signal an exit request. */
            exitRequested_ = true;
        }
        else
        {
            LOGGER_ERROR("Execution stopped. Unable to read");
        }
    }
    LOGGER_INFO("AdaptiveApplication::WaitUntilTermination Exit");
}

/* @brief Reports the terminating state of the AdaptiveApplication. */
void AdaptiveApplication::ReportRunningState()
{
    LOGGER_INFO("AdaptiveApplication::ReportRunningState");
    ara::exec::ExecutionClient execClient;
    ara::core::Result<void, ara::core::ErrorCode> const kExecState{
        execClient.ReportExecutionState(ara::exec::ExecutionState::kRunning)};

    if (kExecState)
    {
        LOGGER_INFO("AdaptiveApplication RunningState Reported");
    }
    else
    {
        LOGGER_INFO("AdaptiveApplication RunningState Not Reported");
    }
}

/* @brief Starts execution of AdaptiveApplication. */
/* @return Success on successful execution else Failure. */
int8_t AdaptiveApplication::Execute()
{
    LOGGER_INFO("AdaptiveApplication::Execute")
    int8_t status;
    /* Check whether application is initalized. */
    if (Initialize())
    {
        static_cast<void>(Run());
        Terminate();
        status = EXIT_SUCCESS;
    }
    else
    {
        status = EXIT_FAILURE;
    }

    return status;
}

/* @brief Method returns whether AdaptiveApplication is initialized. */
/* @return True on success else False. */
bool AdaptiveApplication::Initialize()
{
    LOGGER_INFO("AdaptiveApplication::Initialize");

    struct sigaction sa;
    sa.sa_handler = &SigTermHandler;
    sa.sa_flags   = 0;
    std::int64_t const sigStatus{sigemptyset(&sa.sa_mask)};

    bool isInitialzed{true};
    constexpr std::int32_t kByteMinus1{-1};
    if (!OnInitialize())
    {
        LOGGER_INFO("Initialization Unsuccessful");
        isInitialzed = false;

        /* Creating a pipe */
    }
    else if (pipe(selfPipe_.data()) == kByteMinus1)
    {
        /* Could not create a pipe for performing a classic self pipe trick */
        LOGGER_ERROR("Execution stopped. Unable to create a pipe");
        isInitialzed = false;
    }
    else if (sigStatus == kSocketClose)
    {
        isInitialzed = false;
        /* register signal handler */
    }
    else if (static_cast<std::int64_t>(sigaction(kSigTerm, &sa, nullptr)) == kSocketClose)
    {
        /* Could not register a SIGTERM signal handler */
        LOGGER_ERROR("Execution stopped. Unable to register signal handler");
        CloseSelfPipe();
        isInitialzed = false;
    }
    else
    {
        LOGGER_INFO("Initialization Successful");
    }

    return isInitialzed;
}

/* @brief Reports the terminating state of the AdaptiveApplication. */
void AdaptiveApplication::ReportTerminatingState() const
{
    LOGGER_INFO("AdaptiveApplication::ReportTerminatingState");
    ara::exec::ExecutionClient execClient;
    ara::core::Result<void, ara::core::ErrorCode> const execState{
        execClient.ReportExecutionState(
            ara::exec::ExecutionState::kTerminating)};

    if (execState)
    {
        LOGGER_INFO("AdaptiveApplication TerminatingState Reported");
    }
    else
    {
        LOGGER_INFO("AdaptiveApplication TerminatingState Not Reported");
    }
}

/* @brief Reports the terminating state of the AdaptiveApplication. */
/* @return boolean*/
bool AdaptiveApplication::IsTerminateRequested()
{
    return exitRequested_;
}

/* @brief Terminates the AdaptiveApplication. */
void AdaptiveApplication::Terminate()
{
    LOGGER_INFO("AdaptiveApplication::Terminate");
    ReportTerminatingState();
    static_cast<void>(OnTerminate());
    CloseSelfPipe();
}

/* @brief Closes the reading and writing pipe of AdaptiveApplication. */
void AdaptiveApplication::CloseSelfPipe() const
{
    LOGGER_INFO("AdaptiveApplication::CloseSelfPipe");
    std::int64_t closeStatus{close(selfPipe_[kPipeReadingEnd_])};
    if (closeStatus == kSocketClose)
    {
        LOGGER_INFO("Read Pipe Not Closed");
    }

    closeStatus = close(selfPipe_[kPipeWritingEnd_]);

    if (closeStatus == kSocketClose)
    {
        LOGGER_INFO("Write Pipe Not Closed");
    }
}
} // namespace adaptive
