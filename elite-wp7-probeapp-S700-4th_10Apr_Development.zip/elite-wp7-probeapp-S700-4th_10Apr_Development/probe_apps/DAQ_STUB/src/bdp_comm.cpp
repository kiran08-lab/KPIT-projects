
/*                                                                                                  */
/*                                                                                                  */
/*  @copyright  (C) KPIT Technologies Limited                                                       */
/*              Created in 2024 as an unpublished copyright work.                                   */
/*              All rights reserved.                                                                */
/*              KPIT Technologies Limited owns all the rights to this work. This                    */
/*              work shall not be copied, reproduced, used, modified or its information             */
/*              disclosed without the prior written authorization of KPIT Technologies              */
/*              Limited.                                                                            */
/*   @file      bdp_comm.cpp                                                                        */
/*   @brief     #cfe: This file contains the method declaration.                                    */
/*   @details   --                                                                                  */
/*   @version   Revision 1.0                                                                        */
/*   @date      24/08/2024                                                                          */
/*   @bug       --                                                                                  */
/*   @warning   --                                                                                  */
/*                                                                                                  */
/* Revision History:                                                                                */
/*   			1.0 																				*/   
/*					  1. Initial version.                                                           */

#include <string>
#include <iostream>
#include <cstdint>
#include "bdp_comm.h"
#include <chrono>

//using namespace honda::daq::core_probe_daq_continual_service_;
using ara::com::InstanceIdentifier;

namespace Honda
{
    namespace DAQ
    {

    /* Constructor for DaqContinual class */    
    /*DaqContinual(ara::com::InstanceIdentifier instance_id)
    :CORE_PROBE_DAQ_continual_ServiceSkeleton(instance_id, ara::com::MethodCallProcessingMode::kEvent)
{
}*/
    }
}
    

