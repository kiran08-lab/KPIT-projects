/*                                                                                                          */
/*                                                                                                          */
/*  @copyright  (C) KPIT Technologies Limited                                                               */
/*              Created in 2024 as an unpublished copyright work.                                           */
/*               All rights reserved.                                                                       */
/*              KPIT Technologies Limited owns all the rights to this work. This                            */
/*              work shall not be copied, reproduced, used, modified or its information                     */
/*              disclosed without the prior written authorization of KPIT Technologies                      */
/*              Limited.                                                                                    */
/*   @file      daq_comm.cpp                                                                                */
/*   @brief     #cfe: This file contains the communication/service implementation for DAQ Stub.             */
/*   @date      18/09/2024                                                                                  */
/*   @version   9.0 :                                                                                       */
/*   @version history:                                                                                      */
/*              1.0 :                                                                                       */
/*                    1. Initial version.                                                                   */
/*              2.0 :                                                                                       */
/*					  1. Update/Modify variable name according to newly provided VB00 ARXML,    	        */
/*					   	 for MPU route , GNSS , HDf Trigger, Camera Images and DAQ event Interfaces         */
/*                    2. Compute picture size for camera images.                                            */
/*                                                                                                          */
/*			    3.0                     															        */
/*					  1.  Added code changes for Short and Long continual data.                             */
/*                    2.  Continual short data with sampling rate 100ms and continual long data             */
/*                        with sampling rate 1000ms VB00 requirement.                                       */
/*				4.0                                                                                         */
/*                    1.  modified the logic to store the received daq event dara in to the--               */
/*                        rcv_data.txt file previously it was stored the last 10 daq event --               */
/*                        data at a time                                                                    */
/*				5.0   																				        */
/*                    1. Updated logic to logged the DAQ event in to the rcv_data.txt file                  */
/*   			6.0         																	            */
/*                    1. Added code changes for camera image data as per VC00 ARXML                         */
/*                    2. Added code changes for zat hdf trigger, probe-zat communication,                   */
/*                       camera adb event as per VC00 ARXML.                                                */
/*                    3. Modified ADB/TSR event code as per VC00 ARXML.                                     */
/*   			7.0         																	            */
/*                    1. Added code changes for HDF-PROBE (G-HDF) communication                             */
/*                    2. Added code changes for TSR-PROBE communication                                     */
/*                    3. Added code changes for ICCOMMW-PROBE(A-HDF) communication                          */
/*                    4. Added code changes for CAMERAHOST-PROBE(A-HDF/G-HDF) communication                 */
/*                    5. Added code changes for MPU message 13 and MPU message 24 communication             */
/*                    6. Added code changes for CAMERAHOST-PROBE(AnswerBack_EVT) communication              */
/*                    7. Removed implementation for CAM2ADB, CAM2TSR, CAM2TLI and Camera                    */
/*                       --Recognition Input and  Added code changes for SDMAP-PROBE(A-HDF)                 */
/*                       --communication                                                                    */
/*              8.0                                                                                         */
/*                    1. Added code changes for File Logging data as per VC00 requirements.                 */
/*                    2. Added code changes for File Logging data ZAT HDF trigger,                          */
/*                       Camera trigger, Camera images and Daq event as per VC00 requirements.              */
/*                    3. Added the macro for ZAT HDF trigger, Camera trigger, Camera imgaes                 */
/*                       and Daq event File Logging in the cmake file with a switch                         */
/*                       to turn ON/OFF the data file logging.                                              */
/*   			9.0 																				        */
/*					  1. Added code changes for VD00 DAQ Devevent method communication.                     */
/*					  2. Added code changes for VD00 DAQ Continual method communication.                    */
/*                                                                                                          */
/*   @bug       --                                                                                          */
/*   @warning   --                                                                                          */
/*                                                                                                          */

/* Includes. */
#include <iostream>
#include <fstream>
#include "daq_comm.h"
using namespace Honda::DAQ;

/*  OfferService */
/* DAQ Continual Service - pub. */
void DaqComm::OfferServices(void) {
    ara::core::InstanceSpecifier daqContinualPortSpecifier {"Application/AdaptiveApplicationSwComponentTypes/HPROBE1/PPort_HPROBE1_CORE_PROBE_DAQ_continual_Service_SOMEIP"};
    auto daqContinualInstanceIDsRsp = ara::com::runtime::ResolveInstanceIDs (daqContinualPortSpecifier);
    if (daqContinualInstanceIDsRsp.Err().has_value()) {
        //LOGGER_ERROR("[DAQ-Stub]: Error :  {}",daqContinualInstanceIDsRsp.Error());
        throw ara::com::IllegalStateException("[DAQ] Error returned from daqContinualInstanceIDsRsp");
    }
    ara::com::InstanceIdentifierContainer daqContinualInstanceIDs = daqContinualInstanceIDsRsp.Value();
    //LOGGER_INFO("[DAQ-Stub]: Searching for DAQ Continual Service Instance: {}",daqContinualInstanceIDs[0]);
    daqContinualServiceInstance_ = std::make_unique<Honda::DAQ::DaqContinual>(daqContinualInstanceIDs[0]);
    static_cast<void> (daqContinualServiceInstance_->OfferService());
}

/*                                                                                                                          */
/* @name  StopOfferServices.                                                                                                */
/* @brief Stop offering provided services.                                                                                  */
/*                                                                                                                          */
void DaqComm::StopOfferServices (void) {
    /* Stop service call for the services offered. */
    LOGGER_INFO("[DAQ-Stub]: inside of StopOfferServices ");
    daqContinualServiceInstance_->StopOfferService();
}

/*                                                                                                                                                                        */
/* @name   CORE_PROBE_DAQ_continual_Service_hprobe1TransmissionInformationBusOut_FIR_FGT.                                                                                  */
/* @brief  Definition for DAQ Continual method CORE_PROBE_DAQ_continual_Service_hprobe1TransmissionInformationBusOut_FIR_FGT - Continual data input from ProbeApp          */
/* @param  regularSignalData - TransmissionInformation_STRUCTURE - Continual data input from ProbeApp                                                                     */                                                                                                            
 
void DaqContinual::CORE_PROBE_DAQ_continual_Service_hprobe1TransmissionInformationBusOut_FIR_FGT(
    const ::hprobe1TransmissionInformationBusOut_STRUCTURE& UML_Parameter1)
{
    LOGGER_INFO("[DAQ] PROBE_DAQ continual data received");

#ifdef ENABLE_DAQ_FILE_LOGGING  

    static const std::string directory = "/data/";
    int saved_errno = errno;

    /* Ensure directory exists */
    static bool directoryCreated = false;
    if (!directoryCreated) {
        if (mkdir(directory.c_str(), 0777) == -1) {
            if (errno != EEXIST) {
                saved_errno = errno;
                LOGGER_INFO("Error ensuring directory: {} - {}",
                            directory,
                            std::error_code(saved_errno,
                                            std::system_category()).message());
                return;
            }
        }
        directoryCreated = true;
    }

    /* Log PDU ID and data size */
    LOGGER_INFO("[DAQ] Received PDU ID: 0x{:08X} Size: {}", 
                UML_Parameter1.uedPduId,
                UML_Parameter1.uedDataVector.size());

    /* Derive message number from PDU ID */
    uint16_t msgNumber =
        static_cast<uint16_t>(UML_Parameter1.uedPduId & 0xFF);

    if (msgNumber == 0 || msgNumber > 33) {
        LOGGER_INFO("[DAQ] Invalid message number derived from PDU ID: {}",
                    msgNumber);
        return;
    }

    /* Create file name */
    char fileName[64];
    std::snprintf(fileName,
                  sizeof(fileName),
                  "AD_DAQ_Probe_Message_%02u.bin",
                  msgNumber);

    std::string fullpath = directory + fileName;

    /* Open file */
    std::ofstream dataFileHandle(fullpath,
                                 std::ios::out |
                                 std::ios::binary |
                                 std::ios::trunc);

    if (!dataFileHandle) {
        saved_errno = errno;
        LOGGER_INFO("Failed to create data file! {}",
                    std::error_code(saved_errno,
                                    std::system_category()).message());
        return;
    }

    /* Write raw binary data */
    dataFileHandle.write(
        reinterpret_cast<const char*>(UML_Parameter1.uedDataVector.data()),
        UML_Parameter1.uedDataVector.size());

    dataFileHandle.flush();
    dataFileHandle.close();

    LOGGER_INFO("[DAQ] Message {} written successfully ({} bytes)",
                msgNumber,
                UML_Parameter1.uedDataVector.size()); 

#endif

#ifdef ENABLE_FILE_LOGGING  
    // Directory where data files will be created
    static const std::string directory = "/data/";
    // Ensure the directory exists
    static bool directoryCreated = false;
    if (!directoryCreated) {
        if (mkdir(directory.c_str(), 0777) == -1) {
            LOGGER_ERROR("Failed to create data file!  {}",(directory) << " - " << strerror(errno));
        } else {
            directoryCreated = true;
        }
    }
    // Define the base name for the receiver file
    static const std::string fileName = directory + "daq_rcv_data.txt";
    // Open the file for writing
    static std::ofstream dataFileHandle;
    if (!dataFileHandle.is_open()) {
        dataFileHandle.open(fileName, (std::ios_base::out | std::ios_base::app));
        if (!dataFileHandle) {
            LOGGER_ERROR("Failed to create data file! " );
            return;
        }
    }
    // Write the data to the log file
    static int indexCnt = 0;
    dataFileHandle.flush();
    LOGGER_INFO("[DAQ] UML_Parameter1.uedDataVector.size():  {}",UML_Parameter1.uedDataVector.size());
            for (size_t prntVal = 0; prntVal < UML_Parameter1.uedDataVector.size(); prntVal++) {
                dataFileHandle << "Data index = " << indexCnt << ", position = " << prntVal << ", " << static_cast<uint16_t>(UML_Parameter1.uedDataVector[prntVal]) << std::endl;
            }
    
    if (indexCnt == 31) {
        indexCnt = 0;
    }
    indexCnt++; 
    dataFileHandle.flush();
    LOGGER_INFO("[DAQ] Message signal's data logging completed... ");
#endif
}
/*                                          */
/* @name:   DaqComm.                        */
/* @brief:  Constructor for DaqComm class.  */
/*                                          */
DaqComm::DaqComm (void) 
{
	/* Do nothing. */
}


