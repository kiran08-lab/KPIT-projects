/*                                                                                                  */
/*                                                                                                  */
/*  @copyright  (C) KPIT Technologies Limited                                                       */
/*              Created in 2024 as an unpublished copyright work.                                   */
/*               All rights reserved.                                                               */
/*              KPIT Technologies Limited owns all the rights to this work. This                    */
/*              work shall not be copied, reproduced, used, modified or its information             */
/*              disclosed without the prior written authorization of KPIT Technologies              */
/*              Limited.                                                                            */
/*   @file      main.cpp                                                                            */
/*   @brief     #cfe: This file contains the main call for DAQ Stub.                                */
/*   @details   --                                                                                  */
/*   @version   Revision 6.0                                                                        */
/*   @date      12/06/2024                                                                          */
/*   @bug       --                                                                                  */
/*   @warning   --                                                                                  */
/*                                                                                                  */
/* Revision History:                                                                                */
/* Version Release-Milestone Description                                                            */
/*   1.0 	   M2.1-FY23     Initial version.                                                       */
/*   2.0       M2.2-FY23     Added modifications to send HDF trigger periodically or based on--     */
/*                           --readings from hdf_trigger.json file.                                 */
/*   3.0       M3.3-FY23     Fixed multiple issues with multi-threading.                            */
/*   4.0       M8.1-FY23     Split InitializeServices() call to match ProbeApp codeflow design.     */
/*   5.0       M11.1-FY24    Added route and camera recognition data at different sampling rate.    */
/*   6.0       M4.1-FY24     1. Added changes for HDF-PROBE (G-HDF) communication.                  */
/*                           2. Added changes for TSR-PROBE communication.                          */
/*                           3. Added changes for ICCOMMW-PROBE(A-HDF) communication.               */
/*                           4. Added changes for CAMERAHOST-PROBE(A-HDF/G-HDF) communication.      */
/*                           5. Added changes for MPU message 13 and MPU message 24 communication.  */
/*                           6. Added changes for CAMERAHOST-PROBE(AnswerBack_EVT) communication.   */
/*                           7. Removed CAM2ADB, CAM2TSR, CAM2TLI and Camera Recognition Input      */
/*                              Added changes for SDMAP-PROBE(A-HDF) communication                  */
/*                           8. Removed unused code from HdfTriggerTxThread().                      */

/* Includes. */
#include <stdio.h>
#include <stdint.h>
#include <thread>
#include <chrono>
#include <csignal>
#include <ara/com/e2exf/status_handler.h>
#include <ara/exec/execution_client.h>
#include "ara/core/initialization.h"
#include "daq_comm.h"

/* Global containers. */
/* This holds the external signal value to signal threads to halt. */
static volatile std::sig_atomic_t sigVal;

/*                                      */
/* @name:   sigHandler.                 */
/* @brief:  Registered signal handler.  */
/* @param:  Signal.                     */
/*                                      */
void sigHandler (int inpSig) {
    sigVal = inpSig;
}

/*                                      */
/* @name:   main.                       */
/* @brief:  This is the main function.  */
/* @return: Execution status.           */
/*                                      */
int main (void) {
    setSpdlogConfig("DAQ");
    /* Instance of DaqStub class. */
    DaqComm daqCommHandler;

    /* Initialize signal handler. */
    signal(SIGTERM, sigHandler);
    signal(SIGINT, sigHandler);

    /* Report execution sts (running) to EM. */
    ara::exec::ExecutionClient execClient;
    execClient.ReportExecutionState (ara::exec::ExecutionState::kRunning);
    /* Initialize application. */
    if(!ara::core::Initialize()){
        /* Output an error message to std::cerr (unbuffered stream). */
        LOGGER_ERROR("[DAQ-Stub] aracore Initialization failed" );
        TRACELOG_T(trace_logf(_NTO_TRACE_USERFIRST, "+%s", "[DAQ-Stub] aracore Initialization failed");)
        return DAQSTUB_APP_FAILURE;
    }
    LOGGER_INFO("[DAQ-Stub] Intializing ..... ");

    daqCommHandler.OfferServices();
    LOGGER_INFO("[DAQ-Stub]: Completion of offerServices ");
    while (1) {
        std::this_thread::sleep_for (std::chrono::milliseconds(100));
    }

    /* Stop offered services. */
    daqCommHandler.StopOfferServices();
    
    /* Report execution sts (terminating) to EM. */
    execClient.ReportExecutionState (ara::exec::ExecutionState::kTerminating);
    std::this_thread::sleep_for (std::chrono::milliseconds(50));
    /* Deinitialize application. */
    if(!ara::core::Deinitialize()){
        LOGGER_ERROR("[DAQ-Stub] aracore Deinitialize failed" );
        TRACELOG_T(trace_logf(_NTO_TRACE_USERFIRST, "+%s", "[DAQ-Stub] aracore Deinitialize failed");)
        return DAQSTUB_APP_FAILURE;
    }

    /* This is logged because all threads are expected to operate indefinitely. */
    LOGGER_ERROR("[DAQ-Stub] SIGTERM Daq Comm terminated ! ! ! ");
    TRACELOG_T(trace_logf(_NTO_TRACE_USERFIRST, "+%s", "[DAQ-Stub] SIGTERM Daq Comm terminated ! ! ! ");)
    return DAQSTUB_APP_SUCCESS;
}



