/*                                                                                                  */
/*                                                                                                  */
/*  @copyright  (C) KPIT Technologies Limited                                                       */
/*              Created in 2024 as an unpublished copyright work.                                   */
/*               All rights reserved.                                                               */
/*              KPIT Technologies Limited owns all the rights to this work. This                    */
/*              work shall not be copied, reproduced, used, modified or its information             */
/*              disclosed without the prior written authorization of KPIT Technologies              */
/*              Limited.                                                                            */
/*   @file      daq_comm.h                                                                          */
/*   @brief     #cfe: This file contains the class declaration for DaqComm class.                   */
/*   @details   --                                                                                  */
/*   @version   Revision 2.0                                                                        */
/*   @date      10/09/2024                                                                          */
/*   @bug       --                                                                                  */
/*   @warning   --                                                                                  */
/*                                                                                                  */

/* Revision History:                                                                                */
/*   			1.0 																				*/   
/*					  1. Initial version.                                                           */
/*   			2.0 																				*/   
/*					  1. Added code changes for VD00 DAQ Devevent method communication.             */
/*					  2. Added code changes for VD00 DAQ Continual method communication.            */

#ifndef __includes_DaqComm_h
#define __includes_DaqComm_h

/* Includes. */
#include <map>
#include <memory>
#include <iostream>
#include <cmath>
#include <random>
#include <string>
#include <cstdint>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <ara/core/future.h>
#include <ara/core/promise.h>
#include "ara/core/instance_specifier.h"
#ifdef ENABLE_FILE_LOGGING
    #include <sys/stat.h>
    #include <dirent.h>
    #include <fstream>
#endif
#include "bdp_comm.h"
#include "daq_macros.h"
 
using namespace honda::daq::core_probe_daq_continual_service_;
 
/* Constants. */
/* Number of bytes to be printed from in/out interface data for logs. */
const uint32_t kDaqDebugLogCheckBytes = 0x05U;

/* DaqComm class. */
class DaqComm {
public:
    /* Offer services. */
    void OfferServices (void);
    /* Stop offered services. */
    void StopOfferServices (void);

    /* Constructor. */
    DaqComm (void);
	
    /* Dynamic memory allocation container for DAQ Continual service skeleton. */
    std::unique_ptr<Honda::DAQ::DaqContinual> daqContinualServiceInstance_; 
};

#endif

