

#ifndef SPDLOGGER_H_

#define SPDLOGGER_H_

#include <stdio.h>
#include "spdlog/spdlog.h"

// LOGGER NAME
#define DEFAULT_LOGGER "defaultlogger"  // default logger name
#define ERROR_LOGGER "errlogger"        // error logger name

// TRACELOG OUTPUT
#define LOGGER_TRACE( ... ) \
    do{\
        if(spdlog::get_level()<=spdlog::level::trace){\
            spdlog::log(spdlog::source_loc{__FILE__, __LINE__, __FUNCTION__}, spdlog::level::trace, __VA_ARGS__ );\
        }\
    }while(0)
// DEBUGLOG OUTPUT
#define LOGGER_DEBUG( ... ) \
    do{\
        if(spdlog::get_level()<=spdlog::level::debug){\
            spdlog::log(spdlog::source_loc{__FILE__, __LINE__, __FUNCTION__}, spdlog::level::debug, __VA_ARGS__ );\
        }\
    }while(0)
// INFOLOG OUTPUT
#define LOGGER_INFO( ... ) \
    do{\
        if(spdlog::get_level()<=spdlog::level::info){\
            spdlog::log(spdlog::source_loc{__FILE__, __LINE__, __FUNCTION__}, spdlog::level::info, __VA_ARGS__ );\
        }\
    }while(0)
// WARNNINGLOG OUTPUT
#define LOGGER_WARN( ... ) \
    do{\
        if(spdlog::get_level()<=spdlog::level::warn){\
            spdlog::log(spdlog::source_loc{__FILE__, __LINE__, __FUNCTION__}, spdlog::level::warn, __VA_ARGS__ );\
        }\
    }while(0)
// ERRORLOG OUTPUT
#define LOGGER_ERROR( ... ) \
    do{\
        if(spdlog::get_level()<=spdlog::level::err){\
            spdlog::log(spdlog::source_loc{__FILE__, __LINE__, __FUNCTION__}, spdlog::level::err, __VA_ARGS__ );\
            spdlog::get(ERROR_LOGGER)->log(spdlog::source_loc{__FILE__, __LINE__, __FUNCTION__}, spdlog::level::err, __VA_ARGS__ );\
        }\
    }while(0)
// CRITICALLOG OUTPUT
#define LOGGER_CRITICAL( ... ) \
    do{\
        if(spdlog::get_level()<=spdlog::level::critical){\
            spdlog::log(spdlog::source_loc{__FILE__, __LINE__, __FUNCTION__}, spdlog::level::critical, __VA_ARGS__ );\
            spdlog::get(ERROR_LOGGER)->log(spdlog::source_loc{__FILE__, __LINE__, __FUNCTION__}, spdlog::level::critical, __VA_ARGS__ );\
        }\
    }while(0)

// Setting SpdlogConfig
void setSpdlogConfig(std::string appname);

#endif // SPDLOGGER_H_

