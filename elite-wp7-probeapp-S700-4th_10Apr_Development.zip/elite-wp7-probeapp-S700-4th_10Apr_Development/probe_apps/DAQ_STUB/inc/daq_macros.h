/*                                                                                                                  */
/*                                                                                                                  */
/*  @copyright  (C) KPIT Technologies Limited                                                                       */
/*              Created in 2025 as an unpublished copyright work.                                                   */
/*              All rights reserved.                                                                                */
/*              KPIT Technologies Limited owns all the rights to this work. This                                    */
/*              work shall not be copied, reproduced, used, modified or its information                             */
/*              disclosed without the prior written authorization of KPIT Technologies                              */
/*              Limited.                                                                                            */
/*   @file      daq_macros.h                                                                                        */
/*   @brief     #cfe: This file contains the macros used throughout DAQ App.                                        */
/*   @details   --                                                                                                  */
/*   @version   1.0                                                                                                 */
/*   @date      08/10/2025                                                                                          */
/*   @bug       --                                                                                                  */
/*   @warning   --                                                                                                  */
/*                                                                                                                  */
/* Revision History:                                                                                                */
/* Version Release-Milestone Description                                                                            */
/*              1.0                                                	                                                */
/*                  1. Initial version.                                            	                                */
/*                                                                                                                  */
/*                                                                                                                  */
/*   @bug       --                                                                                                  */
/*   @warning   --                                                                                                  */
/*                                                                                                                  */

/********************************************************************/
/*                  DAQSTUB APP - LOGGING FUNCTION                */
/********************************************************************/

/* Macro functions to enable logging based on MakeFile options 'TRACELOG' */
#ifdef TRACELOG
    #define TRACELOG_T(log) log
#else
    #define TRACELOG_T(log)
#endif

/********************************************************************/
/*                  DAQSTUB APP - MAIN FUNCTION                   */
/********************************************************************/
#define DAQSTUB_APP_SUCCESS           0x00
#define DAQSTUB_APP_FAILURE           0x01
