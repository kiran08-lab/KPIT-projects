/*                                                                                                  	*/
/*                                                                                                  	*/
/*  @copyright  (C) KPIT Technologies Limited                                                       	*/
/*              Created in 2024 as an unpublished copyright work.                                   	*/
/*              All rights reserved.                                                                	*/
/*              KPIT Technologies Limited owns all the rights to this work. This                    	*/
/*              work shall not be copied, reproduced, used, modified or its information             	*/
/*              disclosed without the prior written authorization of KPIT Technologies              	*/
/*              Limited.                                                                            	*/
/*   @file      daq_timer.h                                                                       	    */
/*   @brief     #cfe: This file contains the class declaration for daq timer class.               	    */
/*   @details   --                                                                                  	*/
/*   @version   Revision 1.0                                                                        	*/
/*   @date      26/02/2024                                                                          	*/
/*   @bug       --                                                                                  	*/
/*   @warning   --                                                                                  	*/
/*                                                                                                  	*/

/* Revision History:                                                                                	*/
/* Version Release-Milestone Description                                                            	*/
/*              1.0       M11.1-FY24     Initial version.                                            	*/ 
 
#ifndef __includes_DaqTimer_h
#define __includes_DaqTimer_h

/* Includes. */
#include <thread>
#include <chrono>
#include <functional>
#include <cstdio>
#include <atomic>
#include <iostream>

/* Macros. */
/* Timer counter for Route data send. */
#define TIMER_ROUTE_COUNT   10

/* DaqTimer class. */
class DaqTimer {
public:
     /* Distructor of DaqTimer class. */
    ~DaqTimer() {
        if (mRunning) {
            stop();
        }
    }
	/* Defining own identifiers. */
    typedef std::chrono::milliseconds Interval;
    typedef std::function<void(void)> Timeout;
    /* Timer to start at different perodicity. */
    void start(const Interval &interval, const Timeout &timeout) {
        mRunning = true;
        /* Thread to run independently with a given interval. */
        mThread = std::thread([this, interval, timeout] {
            while (mRunning) {
               std::this_thread::sleep_for(interval);
                timeout();
            }
        });
    }
	/* Timer to stop. */
    void stop() {
        mRunning = false;
		/* Wait for thread to complete exec. */
        mThread.join();
    }

private:
    std::thread mThread{};
    std::atomic_bool mRunning{};
};

#endif

