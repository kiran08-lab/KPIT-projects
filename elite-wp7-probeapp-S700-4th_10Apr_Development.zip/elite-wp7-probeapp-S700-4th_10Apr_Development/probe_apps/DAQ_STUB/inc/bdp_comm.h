/*                                                                                                  */
/*                                                                                                  */
/*  @copyright  (C) KPIT Technologies Limited                                                       */
/*              Created in 2024 as an unpublished copyright work.                                   */
/*              All rights reserved.                                                                */
/*              KPIT Technologies Limited owns all the rights to this work. This                    */
/*              work shall not be copied, reproduced, used, modified or its information             */
/*              disclosed without the prior written authorization of KPIT Technologies              */
/*              Limited.                                                                            */
/*   @file      bdp_comm.h                                                                          */
/*   @brief     #cfe: This file contains the method declaration.                                    */
/*   @details   --                                                                                  */
/*   @version   Revision 1.0                                                                        */
/*   @date      22/08/2024                                                                          */
/*   @bug       --                                                                                  */
/*   @warning   --                                                                                  */
/*                                                                                                  */

/* Revision History:                                                                                */
/*   			1.0 																				*/
/*					  1. Initial version.                                                           */

#ifndef __includes_BdpComm_h
#define __includes_BdpComm_h

#include <stdio.h>
#include <stdint.h>
#include <string>
#include <memory>
#include <ara/core/future.h>
#include <ara/core/promise.h>
/* c4kgen files */
#include "honda/daq/core_probe_daq_continual_service_skeleton.h"
#include "spdlogger.h"
//using Skeleton = honda::daq::skeleton::CORE_PROBE_DAQ_continual_ServiceSkeleton;
using namespace honda::daq::core_probe_daq_continual_service_;

using ara::com::InstanceIdentifier;
namespace Honda
{
    namespace DAQ
    {
    /* Overriding virtual methods in CORE_DAQ_continual_ServiceSkeleton class */
    //class DaqContinual : public Honda::DAQ::skeleton::CORE_DAQ_continual_ServiceSkeleton {
    class DaqContinual : public honda::daq::skeleton::CORE_PROBE_DAQ_continual_ServiceSkeleton {

    public :
    explicit DaqContinual(ara::com::InstanceIdentifier instance_id)
    :CORE_PROBE_DAQ_continual_ServiceSkeleton(instance_id, ara::com::MethodCallProcessingMode::kEvent)
    {
    }
        /* Method call for DAQ Continual Fire and Forget. */
        virtual void CORE_PROBE_DAQ_continual_Service_hprobe1TransmissionInformationBusOut_FIR_FGT(const ::honda::daq::core_probe_daq_continual_service_::hprobe1TransmissionInformationBusOut_STRUCTURE& UML_Parameter1) override;
    };
  }
}


#endif 
