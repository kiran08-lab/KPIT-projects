// @copyright  (C) KPIT Technologies Limited
//             Created in 2022 as an unpublished copyright work.
//              All rights reserved.
//             KPIT Technologies Limited owns all the rights to this work.This
//             work shall not be copied, reproduced, used, modified or its information
//             disclosed without the prior written authorization of KPIT Technologies
//             Limited.
//  @file      adaptive_app.h
//  @brief     This file contains the class definition
//  @details
//  @version   Revision 1.0
//  @date
//  @bug --
//  @warning --

#ifndef ADAPTIVE_APP_H_
#define ADAPTIVE_APP_H_

#include <atomic>
#include <array>

// @brief adaptive namespace
namespace adaptive
{

// @brief Class describes the processes of Adaptive Application.
class AdaptiveApplication
{
public:
    /* @brief Default Constructor of AdaptiveApplication. */
    AdaptiveApplication() = default;

    /* @brief AdaptiveApplication is not copy constructable. */
    /* @param AdaptiveApplication Instance of AdaptiveApplication. */
    AdaptiveApplication(const AdaptiveApplication &) = delete;

    /* @brief AdaptiveApplication is not copy assignable. */
    /* @param AdaptiveApplication Instance of AdaptiveApplication. */
    AdaptiveApplication &operator=(const AdaptiveApplication &) = delete;

    /* @brief AdaptiveApplication is not move constructable. */
    /* @param AdaptiveApplication Instance of AdaptiveApplication. */
    AdaptiveApplication(AdaptiveApplication &&) = delete;

    /* @brief AdaptiveApplication is not move assignable. */
    /* @param AdaptiveApplication Instance of AdaptiveApplication. */
    AdaptiveApplication &operator=(AdaptiveApplication &&) = delete;

    /* @brief Destructor of AdaptiveApplication. */
    virtual ~AdaptiveApplication() = default;

    /* @brief Starts execution of AdaptiveApplication. */
    /* @return Success on successful execution else Failure. */
    int8_t Execute();

protected:
    /* @brief Method returns whether AdaptiveApplication is initialized. */
    /* @return True on success else False. */
    /* true: success, false: fail */
    virtual bool OnInitialize() = 0;

    /* @brief Runs the AdaptiveApplication. */
    /* true: success, false: fail */
    virtual bool Run() = 0;

    /* @brief Performs processes on termination of the AdaptiveApplication. */
    /* true: success, false: fail */
    virtual bool OnTerminate() = 0;

    /* @brief Checks whether exit is requested for the AdaptiveApplication. */
    /* true: success, false: fail */
    void WaitUntilTermination();

    /* @brief Reports the running state of the AdaptiveApplication. */
    void ReportRunningState();

    /* @brief IsTerminateRequested */
    /* true: success, false: fail */
    bool IsTerminateRequested();

private:
    /* @brief Method returns whether AdaptiveApplication is initialized. */
    /* @return True on success else False. */
    /* true: success, false: fail */
    bool Initialize();

    /* @brief Reports the terminating state of the AdaptiveApplication. */
    /* true: success, false: fail */
    void ReportTerminatingState() const;

    /* @brief Terminates the AdaptiveApplication. */
    /* true: success, false: fail */
    void Terminate();

    /* @brief Closes the reading and writing pipe of AdaptiveApplication. */
    /* true: success, false: fail */
    void CloseSelfPipe() const;

    /* @brief Handles the SIGTERM signals. */
    /* @param sig SigTerm Handler value. */
    /* true: success, false: fail */
    static void SigTermHandler(std::int32_t const sig);

    /* @brief Holds the index value of selfPipe. */
    static constexpr std::int32_t kPipeReadingEnd_{0};

    /* @brief Holds the index value of selfPipe. */
    static constexpr std::int32_t kPipeWritingEnd_{1};

    /* @brief Self Pipe used for read and write. */
    static std::array<int32_t, 2> selfPipe_;

    /* @brief Stores exit requested status. */
    static std::atomic_bool exitRequested_;

    /* @brief Holds the logger instance. */
};
} // namespace adaptive
#endif // ADAPTIVE_APP_H_
